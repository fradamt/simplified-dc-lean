import AvailableChainGridCO.Proofs.Hooks
import AvailableChainKitFG
import AvailableChainGridCO.Tests.Axioms
import AvailableChainSA.Tests.Axioms
import AvailableChainFGSA.Tests.RootCollision
import AvailableChainFGSAClaims.Tests.FinalitySafety
import AvailableChainFGSAProofs.Tests.NonVacuity.HealingRun
import AvailableChainFGSAProofs.Tests.NonVacuity.HealingPackages
import AvailableChainFGSAProofs.Tests.NonVacuity.HealingClaims
import AvailableChainFGSAProofs.Tests.NonVacuity.FinalityClaims
import AvailableChainFGSAInhabit.WeakContinuationW1
import AvailableChainGridCO.Proofs.LegacyMode
import AvailableChainFGSA.Tests.Axioms
import AvailableChainGeneric.Tests.Axioms
import AvailableChainFGSARun.Proofs.NamedDelivery
import AvailableChainFGSARun.Proofs.HeadIdentity
import AvailableChainFGSARun.Proofs.RootResolution
import AvailableChainFGSARun.Proofs.RootLease
import AvailableChainFGSAProofs.Proofs.Shared.ProposalRead
import AvailableChainFGSAProofs.Proofs.Assembly.Root
#check AvailableChain.FGSA.Run.process_namedBodies_subset
#print axioms AvailableChain.FGSA.Run.process_namedBodies_subset
#check AvailableChain.FGSA.Run.proposal_read_named
#print axioms AvailableChain.FGSA.Run.proposal_read_named
#check AvailableChain.FGSA.Run.stored_block_eq_of_root_eq
#print axioms AvailableChain.FGSA.Run.stored_block_eq_of_root_eq
#check AvailableChain.FGSA.Run.headTargetAtEmission_stored
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_stored
#check AvailableChain.FGSA.Run.headTargetAtEmission_scope
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_scope
#check AvailableChain.FGSA.Run.resolvedHead_root
#print axioms AvailableChain.FGSA.Run.resolvedHead_root
#check AvailableChain.FGSA.Run.headTargetAtEmission_receiver_eq
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_receiver_eq
#check AvailableChain.FGSA.Run.headTargetAtEmission_at_tick
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_at_tick
#check AvailableChain.FGSA.Run.headTargetAtEmission_of_stored
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_of_stored
#check AvailableChain.FGSA.Run.stored_eq_headVote
#print axioms AvailableChain.FGSA.Run.stored_eq_headVote
#check AvailableChain.FGSA.Run.namedScope_stored_proposal
#print axioms AvailableChain.FGSA.Run.namedScope_stored_proposal
#check AvailableChain.FGSA.Run.stored_named_body_delivery
#print axioms AvailableChain.FGSA.Run.stored_named_body_delivery
#check AvailableChain.FGSA.Run.stored_named_body_ancestor
#print axioms AvailableChain.FGSA.Run.stored_named_body_ancestor
#check AvailableChain.FGSA.Run.namedProposalInRun_genesis_or_delivered
#print axioms AvailableChain.FGSA.Run.namedProposalInRun_genesis_or_delivered
#check AvailableChain.FGSA.Run.namedProposalInRun_origin
#print axioms AvailableChain.FGSA.Run.namedProposalInRun_origin
#check AvailableChain.FGSA.Run.namedStored_eq
#print axioms AvailableChain.FGSA.Run.namedStored_eq
#check AvailableChain.FGSA.RootLease.root_write_unique_keys
#print axioms AvailableChain.FGSA.RootLease.root_write_unique_keys
#check AvailableChain.FGSA.RootLease.root_write_protectsUntil
#print axioms AvailableChain.FGSA.RootLease.root_write_protectsUntil
#check AvailableChain.FGSA.RootLease.root_expire_protectsUntil
#print axioms AvailableChain.FGSA.RootLease.root_expire_protectsUntil
#check AvailableChain.FGSA.RootLease.root_release_protectsUntil
#print axioms AvailableChain.FGSA.RootLease.root_release_protectsUntil
#check AvailableChain.FGSA.Run.findByRoot_subtree
#print axioms AvailableChain.FGSA.Run.findByRoot_subtree
#check AvailableChain.FGSA.Run.goldfishScoreOn_subtree
#print axioms AvailableChain.FGSA.Run.goldfishScoreOn_subtree
#check AvailableChain.FGSA.Run.clockPre_headDomain
#print axioms AvailableChain.FGSA.Run.clockPre_headDomain
#check AvailableChain.FGSA.Run.actView_score
#print axioms AvailableChain.FGSA.Run.actView_score
#check AvailableChain.FGSA.Run.actView_resolve_of_mem
#print axioms AvailableChain.FGSA.Run.actView_resolve_of_mem
#check AvailableChain.FGSA.Run.resolvedTarget_root
#print axioms AvailableChain.FGSA.Run.resolvedTarget_root
#check AvailableChain.FGSA.Run.resolvedTarget_of_mem
#print axioms AvailableChain.FGSA.Run.resolvedTarget_of_mem
#check AvailableChain.FGSA.Run.base_resolve_target
#print axioms AvailableChain.FGSA.Run.base_resolve_target
#check AvailableChain.FGSA.Run.actView_resolve_target
#print axioms AvailableChain.FGSA.Run.actView_resolve_target
#check AvailableChain.FGSA.Run.clock_stored_block_eq
#print axioms AvailableChain.FGSA.Run.clock_stored_block_eq
#check AvailableChain.FGSA.Run.prefixSupport_body
#print axioms AvailableChain.FGSA.Run.prefixSupport_body
#check AvailableChain.FGSA.Run.confirmation_support_body
#print axioms AvailableChain.FGSA.Run.confirmation_support_body
#check AvailableChain.FGSA.Run.resolvedHead_target
#print axioms AvailableChain.FGSA.Run.resolvedHead_target
#check AvailableChain.FGSA.Run.resolvedHead_of_lookup
#print axioms AvailableChain.FGSA.Run.resolvedHead_of_lookup
#check AvailableChain.FGSA.Run.cleanSupport_domain_score
#print axioms AvailableChain.FGSA.Run.cleanSupport_domain_score
#check AvailableChain.FGSA.Run.actView_target_of_resolvedHead
#print axioms AvailableChain.FGSA.Run.actView_target_of_resolvedHead
#check AvailableChain.FGSA.Run.resolvedTarget_mem
#print axioms AvailableChain.FGSA.Run.resolvedTarget_mem
#check AvailableChain.FGSA.Run.actView_support_in_domain
#print axioms AvailableChain.FGSA.Run.actView_support_in_domain
#check AvailableChain.FGSA.Run.stored_proposal_delivered
#print axioms AvailableChain.FGSA.Run.stored_proposal_delivered
#check AvailableChain.FGSA.Run.stored_fg_body_delivery
#print axioms AvailableChain.FGSA.Run.stored_fg_body_delivery
#check AvailableChain.FGSA.Run.stored_body_delivery
#print axioms AvailableChain.FGSA.Run.stored_body_delivery
#check AvailableChain.FGSA.Run.rootBlockInRun_delivered
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_delivered
#check AvailableChain.FGSA.Run.rootBlockInRun_held
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_held
#check AvailableChain.FGSA.Run.rootBlockInRun_stored
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_stored
#check AvailableChain.FGSA.Run.rootBlockInRun_stored_proposal
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_stored_proposal
#check AvailableChain.FGSA.Run.stored_body_ancestor
#print axioms AvailableChain.FGSA.Run.stored_body_ancestor
#check AvailableChain.FGSA.Run.emitted_proposal_parent_stored
#print axioms AvailableChain.FGSA.Run.emitted_proposal_parent_stored
#check AvailableChain.FGSA.Run.emitted_proposal_slot_root
#print axioms AvailableChain.FGSA.Run.emitted_proposal_slot_root
#check AvailableChain.FGSA.Run.rootBlockInRun_genesis_or_delivered
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_genesis_or_delivered
#check AvailableChain.FGSA.Run.rootBlockInRun_origin
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_origin
#check AvailableChain.FGSA.Run.contentAgree_run
#print axioms AvailableChain.FGSA.Run.contentAgree_run
#check AvailableChain.FGSA.Run.fgsa_emits_head
#print axioms AvailableChain.FGSA.Run.fgsa_emits_head
#check AvailableChain.FGSA.Run.fgsa_receiptCoverage
#print axioms AvailableChain.FGSA.Run.fgsa_receiptCoverage
#check AvailableChain.FGSA.Run.fgsa_proposal_receipt
#print axioms AvailableChain.FGSA.Run.fgsa_proposal_receipt
#check AvailableChain.FGSA.Run.fgsa_honest_head_receipt
#print axioms AvailableChain.FGSA.Run.fgsa_honest_head_receipt
#check AvailableChain.FGSA.Run.headTargetAtEmission_exists
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_exists
#check AvailableChain.FGSA.Run.headTargetAtEmission_unique
#print axioms AvailableChain.FGSA.Run.headTargetAtEmission_unique
#check AvailableChain.FGSA.Run.namedProposal_eq
#print axioms AvailableChain.FGSA.Run.namedProposal_eq
#check AvailableChain.FGSA.Run.namedAncestor_eq
#print axioms AvailableChain.FGSA.Run.namedAncestor_eq
#check AvailableChain.FGSA.Run.rootBlockInRun_eq
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_eq
#check AvailableChain.FGSA.Run.rootInjectiveOn_run
#print axioms AvailableChain.FGSA.Run.rootInjectiveOn_run
#check AvailableChain.FGSA.Run.fgsa_sameLabel
#print axioms AvailableChain.FGSA.Run.fgsa_sameLabel
#check AvailableChain.FGSA.Run.fgsa_release_bound
#print axioms AvailableChain.FGSA.Run.fgsa_release_bound
#check AvailableChain.FGSA.Run.fgsa_score_eq_on_run
#print axioms AvailableChain.FGSA.Run.fgsa_score_eq_on_run
#check AvailableChain.FGSA.Run.fgsa_ghost_transfer_sfx_on_run
#print axioms AvailableChain.FGSA.Run.fgsa_ghost_transfer_sfx_on_run
#check AvailableChain.FGSA.Run.fgsaClaims
#print axioms AvailableChain.FGSA.Run.fgsaClaims
#check AvailableChain.FGSA.Run.cpPrefix_of_srcFrame
#print axioms AvailableChain.FGSA.Run.cpPrefix_of_srcFrame
#check AvailableChain.FGSA.Run.fgsaSafetyClaims
#print axioms AvailableChain.FGSA.Run.fgsaSafetyClaims
#check AvailableChain.FGSA.Run.fgsa_wholeRunAgreementClaim
#print axioms AvailableChain.FGSA.Run.fgsa_wholeRunAgreementClaim
#check AvailableChain.FGSA.Run.fgsa_eventPrefixAgreementClaim
#print axioms AvailableChain.FGSA.Run.fgsa_eventPrefixAgreementClaim
#check AvailableChain.FGSA.Run.healing_liveDCFromWindows
#print axioms AvailableChain.FGSA.Run.healing_liveDCFromWindows
#check AvailableChain.FGSA.Run.healing_hTimeClaim
#print axioms AvailableChain.FGSA.Run.healing_hTimeClaim
#check AvailableChain.FGSA.Run.proposal_handlesS_direct
#print axioms AvailableChain.FGSA.Run.proposal_handlesS_direct
#check AvailableChain.FGSA.Run.proposal_handle_in_scope
#print axioms AvailableChain.FGSA.Run.proposal_handle_in_scope
#check AvailableChain.FGSA.Run.proposal_trigger_in_scope
#print axioms AvailableChain.FGSA.Run.proposal_trigger_in_scope
#check AvailableChain.FGSA.Run.stored_content_eq
#print axioms AvailableChain.FGSA.Run.stored_content_eq
#check AvailableChain.FGSA.Run.contentOk_withApp
#print axioms AvailableChain.FGSA.Run.contentOk_withApp
#check AvailableChain.FGSA.Run.withApp_zero_proposalBlock
#print axioms AvailableChain.FGSA.Run.withApp_zero_proposalBlock
#check AvailableChain.FGSA.Run.rowsOk_withApp_proposalBlock
#print axioms AvailableChain.FGSA.Run.rowsOk_withApp_proposalBlock
#check AvailableChain.FGSA.Run.rootBlockInRun_ancestor
#print axioms AvailableChain.FGSA.Run.rootBlockInRun_ancestor
#check AvailableChain.FGSA.Run.storeStepRoots_run
#print axioms AvailableChain.FGSA.Run.storeStepRoots_run
#check AvailableChain.FGSA.Run.emitted_payload_parent_stored
#print axioms AvailableChain.FGSA.Run.emitted_payload_parent_stored
#check AvailableChain.FGSA.Run.rootScope_store
#print axioms AvailableChain.FGSA.Run.rootScope_store
#check AvailableChain.FGSA.Run.rootScope_ancestor
#print axioms AvailableChain.FGSA.Run.rootScope_ancestor
#check AvailableChain.FGSA.Run.rootScope_eq
#print axioms AvailableChain.FGSA.Run.rootScope_eq
#check AvailableChain.FGSA.Run.rootScope_source
#print axioms AvailableChain.FGSA.Run.rootScope_source
#check AvailableChain.FGSA.Run.certified_preceq
#print axioms AvailableChain.FGSA.Run.certified_preceq
#check AvailableChain.FGSA.Run.rootScope_entry
#print axioms AvailableChain.FGSA.Run.rootScope_entry
#check AvailableChain.FGSA.Run.rootScope_justified
#print axioms AvailableChain.FGSA.Run.rootScope_justified
#check AvailableChain.FGSA.Run.rootScope_finalized
#print axioms AvailableChain.FGSA.Run.rootScope_finalized
#check AvailableChain.FGSA.Run.srcFrameAbove_scoped
#print axioms AvailableChain.FGSA.Run.srcFrameAbove_scoped
#check AvailableChain.FGSA.Run.rootScope_result
#print axioms AvailableChain.FGSA.Run.rootScope_result
#check AvailableChain.FGSA.Run.rootScope_belowLabel
#print axioms AvailableChain.FGSA.Run.rootScope_belowLabel
#check AvailableChain.FGSA.fgsa_ordinary_parent_of_live_prefix
#print axioms AvailableChain.FGSA.fgsa_ordinary_parent_of_live_prefix
#check AvailableChain.FGSA.Run.exactHead_of_pivot_ancestry
#print axioms AvailableChain.FGSA.Run.exactHead_of_pivot_ancestry
#check AvailableChain.FGSA.fgsa_ordinary_parent_of_live_cover
#print axioms AvailableChain.FGSA.fgsa_ordinary_parent_of_live_cover
#check AvailableChain.FGSA.Run.finalityRun_parent_scope
#print axioms AvailableChain.FGSA.Run.finalityRun_parent_scope
#check AvailableChain.FGSA.Run.fgsa_runAccountable
#print axioms AvailableChain.FGSA.Run.fgsa_runAccountable
#check AvailableChain.FGSA.Run.rootScope_finality_read
#print axioms AvailableChain.FGSA.Run.rootScope_finality_read
#check AvailableChain.FGSA.Run.cpCompat_of_scopedFrame
#print axioms AvailableChain.FGSA.Run.cpCompat_of_scopedFrame
#check AvailableChain.FGSA.Run.sourceDiscipline_strat
#print axioms AvailableChain.FGSA.Run.sourceDiscipline_strat
#check AvailableChain.FGSA.Run.arming_frame_below
#print axioms AvailableChain.FGSA.Run.arming_frame_below
#check AvailableChain.FGSA.Run.inclusion_frame_below
#print axioms AvailableChain.FGSA.Run.inclusion_frame_below
#check AvailableChain.FGSA.Run.fgsa_pureAccountable
#print axioms AvailableChain.FGSA.Run.fgsa_pureAccountable
#check AvailableChain.FGSA.Run.fgsa_pureAgreement
#print axioms AvailableChain.FGSA.Run.fgsa_pureAgreement
#check AvailableChain.FGSA.Run.fgsa_wholeRunAccountable
#print axioms AvailableChain.FGSA.Run.fgsa_wholeRunAccountable
#check AvailableChain.FGSA.Run.fgsa_finalLock_of_bound
#print axioms AvailableChain.FGSA.Run.fgsa_finalLock_of_bound
#check AvailableChain.FGSA.Run.fgsa_rXing
#print axioms AvailableChain.FGSA.Run.fgsa_rXing
#check AvailableChain.FGSA.Run.healing_rows_above_entry_at_height
#print axioms AvailableChain.FGSA.Run.healing_rows_above_entry_at_height
#check AvailableChain.FGSA.Run.kmid_rows_above_entry
#print axioms AvailableChain.FGSA.Run.kmid_rows_above_entry
#check AvailableChain.FGSA.Run.NamedRootCollisionFree.root_injective
#print axioms AvailableChain.FGSA.Run.NamedRootCollisionFree.root_injective
#check AvailableChain.FGSA.Run.Base₂.idealization
#print axioms AvailableChain.FGSA.Run.Base₂.idealization
#check AvailableChain.KitFG.FGStoreSafety.of_certificate
#print axioms AvailableChain.KitFG.FGStoreSafety.of_certificate
#check AvailableChain.KitFG.simplexStoreInvariant
#print axioms AvailableChain.KitFG.simplexStoreInvariant
#check AvailableChain.FGSA.Run.Tests.NonVacuity.HealingRun.nvRoots
#print axioms AvailableChain.FGSA.Run.Tests.NonVacuity.HealingRun.nvRoots
#check AvailableChain.FGSA.Run.Tests.NonVacuity.HealingPackages.nvRoots
#print axioms AvailableChain.FGSA.Run.Tests.NonVacuity.HealingPackages.nvRoots
#check AvailableChain.FGSA.Run.Tests.NonVacuity.HealingClaims.nvRoots
#print axioms AvailableChain.FGSA.Run.Tests.NonVacuity.HealingClaims.nvRoots
#check AvailableChain.FGSA.Run.Tests.NonVacuity.FinalityClaims.nvRoots
#print axioms AvailableChain.FGSA.Run.Tests.NonVacuity.FinalityClaims.nvRoots
#check AvailableChain.FGSA.Run.Tests.NonVacuity.FinalityClaims.nvLiveDC
#print axioms AvailableChain.FGSA.Run.Tests.NonVacuity.FinalityClaims.nvLiveDC
#check AvailableChain.FGSA.fgStoreSafety
#print axioms AvailableChain.FGSA.fgStoreSafety
#check AvailableChain.FGSA.Window.windowStoreSafety
#print axioms AvailableChain.FGSA.Window.windowStoreSafety
#check AvailableChain.KitFG.simplexStoreSafety
#print axioms AvailableChain.KitFG.simplexStoreSafety
#check AvailableChain.Block.findByRoot?_mem
#print axioms AvailableChain.Block.findByRoot?_mem
#check AvailableChain.Block.findByRoot?_of_unique
#print axioms AvailableChain.Block.findByRoot?_of_unique
#check AvailableChain.Block.findByRoot?_perm
#print axioms AvailableChain.Block.findByRoot?_perm
#check AvailableChain.Block.findByRoot?_root
#print axioms AvailableChain.Block.findByRoot?_root
#check AvailableChain.Block.findByRoot?_spec
#print axioms AvailableChain.Block.findByRoot?_spec
#check AvailableChain.Block.findByRoot?_unique
#print axioms AvailableChain.Block.findByRoot?_unique
#check AvailableChain.FGSA.CStoreInv.Smem
#print axioms AvailableChain.FGSA.CStoreInv.Smem
#check AvailableChain.FGSA.CStoreInv.baseTree
#print axioms AvailableChain.FGSA.CStoreInv.baseTree
#check AvailableChain.FGSA.CStoreInv.fastDom
#print axioms AvailableChain.FGSA.CStoreInv.fastDom
#check AvailableChain.FGSA.CStoreInv.genuineKeys
#print axioms AvailableChain.FGSA.CStoreInv.genuineKeys
#check AvailableChain.FGSA.CStoreInv.leaseKeys
#print axioms AvailableChain.FGSA.CStoreInv.leaseKeys
#check AvailableChain.FGSA.CStoreInv.toInv0
#print axioms AvailableChain.FGSA.CStoreInv.toInv0
#check AvailableChain.FGSA.F_preceq_headInTree
#print axioms AvailableChain.FGSA.F_preceq_headInTree
#check AvailableChain.FGSA.F_preceq_liveRoot
#print axioms AvailableChain.FGSA.F_preceq_liveRoot
#check AvailableChain.FGSA.LeaseBelowOutputStore_def
#print axioms AvailableChain.FGSA.LeaseBelowOutputStore_def
#check AvailableChain.FGSA.MetaInv.blocksNodup
#print axioms AvailableChain.FGSA.MetaInv.blocksNodup
#check AvailableChain.FGSA.MetaInv.stampKeys
#print axioms AvailableChain.FGSA.MetaInv.stampKeys
#check AvailableChain.FGSA.MetaInv.wireTree
#print axioms AvailableChain.FGSA.MetaInv.wireTree
#check AvailableChain.FGSA.Run.CleanBlockDelivery_def
#print axioms AvailableChain.FGSA.Run.CleanBlockDelivery_def
#check AvailableChain.FGSA.Run.CleanOrdinaryDelivery_def
#print axioms AvailableChain.FGSA.Run.CleanOrdinaryDelivery_def
#check AvailableChain.FGSA.Run.CleanState.harmless
#print axioms AvailableChain.FGSA.Run.CleanState.harmless
#check AvailableChain.FGSA.Run.CleanState.leases
#print axioms AvailableChain.FGSA.Run.CleanState.leases
#check AvailableChain.FGSA.Run.CleanState.saved
#print axioms AvailableChain.FGSA.Run.CleanState.saved
#check AvailableChain.FGSA.Run.CleanState.savedOnly
#print axioms AvailableChain.FGSA.Run.CleanState.savedOnly
#check AvailableChain.FGSA.Run.FinalityBlock_def
#print axioms AvailableChain.FGSA.Run.FinalityBlock_def
#check AvailableChain.FGSA.Run.HonestCarrier_def
#print axioms AvailableChain.FGSA.Run.HonestCarrier_def
#check AvailableChain.FGSA.Run.LiveDCConcl_W_def
#print axioms AvailableChain.FGSA.Run.LiveDCConcl_W_def
#check AvailableChain.FGSA.Run.LiveDCFromWindowsStatement_def
#print axioms AvailableChain.FGSA.Run.LiveDCFromWindowsStatement_def
#check AvailableChain.FGSA.Run.OpeningCarrier_W_def
#print axioms AvailableChain.FGSA.Run.OpeningCarrier_W_def
#check AvailableChain.FGSA.Run.RActive_def
#print axioms AvailableChain.FGSA.Run.RActive_def
#check AvailableChain.FGSA.Run.RFrame_def
#print axioms AvailableChain.FGSA.Run.RFrame_def
#check AvailableChain.FGSA.Run.RQCOrigin_def
#print axioms AvailableChain.FGSA.Run.RQCOrigin_def
#check AvailableChain.FGSA.Run.RRec_def
#print axioms AvailableChain.FGSA.Run.RRec_def
#check AvailableChain.FGSA.Run.RStoreCumul_def
#print axioms AvailableChain.FGSA.Run.RStoreCumul_def
#check AvailableChain.FGSA.Run.RStore_def
#print axioms AvailableChain.FGSA.Run.RStore_def
#check AvailableChain.FGSA.Run.Ready_W_def
#print axioms AvailableChain.FGSA.Run.Ready_W_def
#check AvailableChain.FGSA.Run.ReceiptCoveragePremises.deadline
#print axioms AvailableChain.FGSA.Run.ReceiptCoveragePremises.deadline
#check AvailableChain.FGSA.Run.ReceiptCoveragePremises.slotWindow
#print axioms AvailableChain.FGSA.Run.ReceiptCoveragePremises.slotWindow
#check AvailableChain.FGSA.Run.ReceiptCoverageStatement_def
#print axioms AvailableChain.FGSA.Run.ReceiptCoverageStatement_def
#check AvailableChain.FGSA.Run.S_at_def
#print axioms AvailableChain.FGSA.Run.S_at_def
#check AvailableChain.FGSA.Run.contentAgree_of_namedScope
#print axioms AvailableChain.FGSA.Run.contentAgree_of_namedScope
#check AvailableChain.FGSA.Run.emitted_payload_parent_base_stored
#print axioms AvailableChain.FGSA.Run.emitted_payload_parent_base_stored
#check AvailableChain.FGSA.Run.gateResult_def
#print axioms AvailableChain.FGSA.Run.gateResult_def
#check AvailableChain.FGSA.Run.namedOrigin_reachable
#print axioms AvailableChain.FGSA.Run.namedOrigin_reachable
#check AvailableChain.FGSA.Run.namedScope_ancestor
#print axioms AvailableChain.FGSA.Run.namedScope_ancestor
#check AvailableChain.FGSA.Run.namedScope_collision
#print axioms AvailableChain.FGSA.Run.namedScope_collision
#check AvailableChain.FGSA.Run.namedScope_compatible_iff
#print axioms AvailableChain.FGSA.Run.namedScope_compatible_iff
#check AvailableChain.FGSA.Run.namedScope_delivered
#print axioms AvailableChain.FGSA.Run.namedScope_delivered
#check AvailableChain.FGSA.Run.namedScope_erase_injective
#print axioms AvailableChain.FGSA.Run.namedScope_erase_injective
#check AvailableChain.FGSA.Run.namedScope_held
#print axioms AvailableChain.FGSA.Run.namedScope_held
#check AvailableChain.FGSA.Run.namedScope_preceq_iff
#print axioms AvailableChain.FGSA.Run.namedScope_preceq_iff
#check AvailableChain.FGSA.Run.outputS_def
#print axioms AvailableChain.FGSA.Run.outputS_def
#check AvailableChain.FGSA.Run.proposal_trigger_in_root_scope
#print axioms AvailableChain.FGSA.Run.proposal_trigger_in_root_scope
#check AvailableChain.FGSA.Run.sourceCandidates_def
#print axioms AvailableChain.FGSA.Run.sourceCandidates_def
#check AvailableChain.FGSA.accepted_F_facts
#print axioms AvailableChain.FGSA.accepted_F_facts
#check AvailableChain.FGSA.accepted_base_facts
#print axioms AvailableChain.FGSA.accepted_base_facts
#check AvailableChain.FGSA.accepted_rows_decode
#print axioms AvailableChain.FGSA.accepted_rows_decode
#check AvailableChain.FGSA.accepted_st2
#print axioms AvailableChain.FGSA.accepted_st2
#check AvailableChain.FGSA.actView_admitBlock_movedF
#print axioms AvailableChain.FGSA.actView_admitBlock_movedF
#check AvailableChain.FGSA.actView_admitBlock_sameF
#print axioms AvailableChain.FGSA.actView_admitBlock_sameF
#check AvailableChain.FGSA.actView_admitHead
#print axioms AvailableChain.FGSA.actView_admitHead
#check AvailableChain.FGSA.actView_ancestor_closed
#print axioms AvailableChain.FGSA.actView_ancestor_closed
#check AvailableChain.FGSA.actView_antitone
#print axioms AvailableChain.FGSA.actView_antitone
#check AvailableChain.FGSA.actView_blocks
#print axioms AvailableChain.FGSA.actView_blocks
#check AvailableChain.FGSA.actView_eq
#print axioms AvailableChain.FGSA.actView_eq
#check AvailableChain.FGSA.actView_eq_image
#print axioms AvailableChain.FGSA.actView_eq_image
#check AvailableChain.FGSA.actView_fields
#print axioms AvailableChain.FGSA.actView_fields
#check AvailableChain.FGSA.actView_genesis_F
#print axioms AvailableChain.FGSA.actView_genesis_F
#check AvailableChain.FGSA.actView_noVeto
#print axioms AvailableChain.FGSA.actView_noVeto
#check AvailableChain.FGSA.actView_onView
#print axioms AvailableChain.FGSA.actView_onView
#check AvailableChain.FGSA.actView_path
#print axioms AvailableChain.FGSA.actView_path
#check AvailableChain.FGSA.actView_releaseCount_zero
#print axioms AvailableChain.FGSA.actView_releaseCount_zero
#check AvailableChain.FGSA.actView_resolutionTree
#print axioms AvailableChain.FGSA.actView_resolutionTree
#check AvailableChain.FGSA.actView_resolvedHead
#print axioms AvailableChain.FGSA.actView_resolvedHead
#check AvailableChain.FGSA.active_releaseCount_le
#print axioms AvailableChain.FGSA.active_releaseCount_le
#check AvailableChain.FGSA.active_releaseCount_zero
#print axioms AvailableChain.FGSA.active_releaseCount_zero
#check AvailableChain.FGSA.active_resolvedBefore_base
#print axioms AvailableChain.FGSA.active_resolvedBefore_base
#check AvailableChain.FGSA.admitBlock_accepted_eq
#print axioms AvailableChain.FGSA.admitBlock_accepted_eq
#check AvailableChain.FGSA.admitBlock_invalid_rows
#print axioms AvailableChain.FGSA.admitBlock_invalid_rows
#check AvailableChain.FGSA.admitBlock_missingParent
#print axioms AvailableChain.FGSA.admitBlock_missingParent
#check AvailableChain.FGSA.admitBlock_reconcile_harmless
#print axioms AvailableChain.FGSA.admitBlock_reconcile_harmless
#check AvailableChain.FGSA.admitBlock_refused
#print axioms AvailableChain.FGSA.admitBlock_refused
#check AvailableChain.FGSA.admitBlock_sufficient
#print axioms AvailableChain.FGSA.admitBlock_sufficient
#check AvailableChain.FGSA.admitBlock_sufficient_absent
#print axioms AvailableChain.FGSA.admitBlock_sufficient_absent
#check AvailableChain.FGSA.admitHead_base_blocks
#print axioms AvailableChain.FGSA.admitHead_base_blocks
#check AvailableChain.FGSA.admitHead_base_stable
#print axioms AvailableChain.FGSA.admitHead_base_stable
#check AvailableChain.FGSA.admitHead_fastWrite
#print axioms AvailableChain.FGSA.admitHead_fastWrite
#check AvailableChain.FGSA.admitHead_fg
#print axioms AvailableChain.FGSA.admitHead_fg
#check AvailableChain.FGSA.admitHead_genuine
#print axioms AvailableChain.FGSA.admitHead_genuine
#check AvailableChain.FGSA.admitHead_obligations
#print axioms AvailableChain.FGSA.admitHead_obligations
#check AvailableChain.FGSA.admitProposal_base_view
#print axioms AvailableChain.FGSA.admitProposal_base_view
#check AvailableChain.FGSA.admitProposal_headDomain
#print axioms AvailableChain.FGSA.admitProposal_headDomain
#check AvailableChain.FGSA.admitProposal_obligations_slow
#print axioms AvailableChain.FGSA.admitProposal_obligations_slow
#check AvailableChain.FGSA.admitProposal_of_accept
#print axioms AvailableChain.FGSA.admitProposal_of_accept
#check AvailableChain.FGSA.admitProposal_prefix
#print axioms AvailableChain.FGSA.admitProposal_prefix
#check AvailableChain.FGSA.admitProposal_stable
#print axioms AvailableChain.FGSA.admitProposal_stable
#check AvailableChain.FGSA.admitRow_headDomain
#print axioms AvailableChain.FGSA.admitRow_headDomain
#check AvailableChain.FGSA.admitVote_headDomain
#print axioms AvailableChain.FGSA.admitVote_headDomain
#check AvailableChain.FGSA.admitVote_stamps
#print axioms AvailableChain.FGSA.admitVote_stamps
#check AvailableChain.FGSA.admitVote_withBlocks
#print axioms AvailableChain.FGSA.admitVote_withBlocks
#check AvailableChain.FGSA.baseBlocks_rootInj
#print axioms AvailableChain.FGSA.baseBlocks_rootInj
#check AvailableChain.FGSA.base_admitProposal_accepts
#print axioms AvailableChain.FGSA.base_admitProposal_accepts
#check AvailableChain.FGSA.base_headDomain_none
#print axioms AvailableChain.FGSA.base_headDomain_none
#check AvailableChain.FGSA.block?_proposal
#print axioms AvailableChain.FGSA.block?_proposal
#check AvailableChain.FGSA.blockAccepted_contentOk
#print axioms AvailableChain.FGSA.blockAccepted_contentOk
#check AvailableChain.FGSA.blockAccepted_facts
#print axioms AvailableChain.FGSA.blockAccepted_facts
#check AvailableChain.FGSA.blockAccepted_of_wellFormed
#print axioms AvailableChain.FGSA.blockAccepted_of_wellFormed
#check AvailableChain.FGSA.blockAccepted_rowsOk
#print axioms AvailableChain.FGSA.blockAccepted_rowsOk
#check AvailableChain.FGSA.blockAccepted_rowsValid
#print axioms AvailableChain.FGSA.blockAccepted_rowsValid
#check AvailableChain.FGSA.blockAccepted_slot_pos
#print axioms AvailableChain.FGSA.blockAccepted_slot_pos
#check AvailableChain.FGSA.clockPre_eq
#print axioms AvailableChain.FGSA.clockPre_eq
#check AvailableChain.FGSA.clockPre_fastWrite
#print axioms AvailableChain.FGSA.clockPre_fastWrite
#check AvailableChain.FGSA.clockPre_fg
#print axioms AvailableChain.FGSA.clockPre_fg
#check AvailableChain.FGSA.clockPre_fields
#print axioms AvailableChain.FGSA.clockPre_fields
#check AvailableChain.FGSA.clockPre_genuine
#print axioms AvailableChain.FGSA.clockPre_genuine
#check AvailableChain.FGSA.clockPre_obligations_sublist
#print axioms AvailableChain.FGSA.clockPre_obligations_sublist
#check AvailableChain.FGSA.clockPre_stable
#print axioms AvailableChain.FGSA.clockPre_stable
#check AvailableChain.FGSA.clockPre_stamps
#print axioms AvailableChain.FGSA.clockPre_stamps
#check AvailableChain.FGSA.clock_base_blocks
#print axioms AvailableChain.FGSA.clock_base_blocks
#check AvailableChain.FGSA.clock_cumulative
#print axioms AvailableChain.FGSA.clock_cumulative
#check AvailableChain.FGSA.clock_eq_saClockFrom_gate
#print axioms AvailableChain.FGSA.clock_eq_saClockFrom_gate
#check AvailableChain.FGSA.clock_eq_saClockFrom_gate'
#print axioms AvailableChain.FGSA.clock_eq_saClockFrom_gate'
#check AvailableChain.FGSA.clock_eq_saClock_offGate
#print axioms AvailableChain.FGSA.clock_eq_saClock_offGate
#check AvailableChain.FGSA.clock_headDomain
#print axioms AvailableChain.FGSA.clock_headDomain
#check AvailableChain.FGSA.clock_namedBodies
#print axioms AvailableChain.FGSA.clock_namedBodies
#check AvailableChain.FGSA.clock_nest
#print axioms AvailableChain.FGSA.clock_nest
#check AvailableChain.FGSA.clock_proposals
#print axioms AvailableChain.FGSA.clock_proposals
#check AvailableChain.FGSA.clock_rowPool
#print axioms AvailableChain.FGSA.clock_rowPool
#check AvailableChain.FGSA.compat_of_confirmation
#print axioms AvailableChain.FGSA.compat_of_confirmation
#check AvailableChain.FGSA.contentAgree
#print axioms AvailableChain.FGSA.contentAgree
#check AvailableChain.FGSA.contentAgree_projection
#print axioms AvailableChain.FGSA.contentAgree_projection
#check AvailableChain.FGSA.contentAgree_self
#print axioms AvailableChain.FGSA.contentAgree_self
#check AvailableChain.FGSA.contentAgree_symm
#print axioms AvailableChain.FGSA.contentAgree_symm
#check AvailableChain.FGSA.cstoreInv_accepted_pre
#print axioms AvailableChain.FGSA.cstoreInv_accepted_pre
#check AvailableChain.FGSA.cstoreInv_admitBlock
#print axioms AvailableChain.FGSA.cstoreInv_admitBlock
#check AvailableChain.FGSA.cstoreInv_clockPre
#print axioms AvailableChain.FGSA.cstoreInv_clockPre
#check AvailableChain.FGSA.cstoreInv_gateFresh
#print axioms AvailableChain.FGSA.cstoreInv_gateFresh
#check AvailableChain.FGSA.cstoreInv_gateStep
#print axioms AvailableChain.FGSA.cstoreInv_gateStep
#check AvailableChain.FGSA.cstoreInv_init
#print axioms AvailableChain.FGSA.cstoreInv_init
#check AvailableChain.FGSA.cstoreInv_normalizeS
#print axioms AvailableChain.FGSA.cstoreInv_normalizeS
#check AvailableChain.FGSA.cstoreInv_of_sublist
#print axioms AvailableChain.FGSA.cstoreInv_of_sublist
#check AvailableChain.FGSA.cstoreInv_process
#print axioms AvailableChain.FGSA.cstoreInv_process
#check AvailableChain.FGSA.erasedList_rootInj
#print axioms AvailableChain.FGSA.erasedList_rootInj
#check AvailableChain.FGSA.erasedList_subset
#print axioms AvailableChain.FGSA.erasedList_subset
#check AvailableChain.FGSA.fastOrigin_congr
#print axioms AvailableChain.FGSA.fastOrigin_congr
#check AvailableChain.FGSA.fastSet_prefix
#print axioms AvailableChain.FGSA.fastSet_prefix
#check AvailableChain.FGSA.fgHead_stored
#print axioms AvailableChain.FGSA.fgHead_stored
#check AvailableChain.FGSA.fg_eq_of_root_eq_across
#print axioms AvailableChain.FGSA.fg_eq_of_root_eq_across
#check AvailableChain.FGSA.fg_on_block_accepts
#print axioms AvailableChain.FGSA.fg_on_block_accepts
#check AvailableChain.FGSA.fg_step_cases
#print axioms AvailableChain.FGSA.fg_step_cases
#check AvailableChain.FGSA.fgsa_Z_preceq_liveRoot
#print axioms AvailableChain.FGSA.fgsa_Z_preceq_liveRoot
#check AvailableChain.FGSA.fgsa_cleanSupport_no_equivocation
#print axioms AvailableChain.FGSA.fgsa_cleanSupport_no_equivocation
#check AvailableChain.FGSA.fgsa_cleanSupport_seats_subset_late
#print axioms AvailableChain.FGSA.fgsa_cleanSupport_seats_subset_late
#check AvailableChain.FGSA.fgsa_confirmationFrom_covers_majority
#print axioms AvailableChain.FGSA.fgsa_confirmationFrom_covers_majority
#check AvailableChain.FGSA.fgsa_confirmationFrom_exact_of_dominated_suffix
#print axioms AvailableChain.FGSA.fgsa_confirmationFrom_exact_of_dominated_suffix
#check AvailableChain.FGSA.fgsa_conflicting_support_sum_le_late
#print axioms AvailableChain.FGSA.fgsa_conflicting_support_sum_le_late
#check AvailableChain.FGSA.fgsa_early_subset_late
#print axioms AvailableChain.FGSA.fgsa_early_subset_late
#check AvailableChain.FGSA.fgsa_eligible_eq
#print axioms AvailableChain.FGSA.fgsa_eligible_eq
#check AvailableChain.FGSA.fgsa_filtered_anchorClosed
#print axioms AvailableChain.FGSA.fgsa_filtered_anchorClosed
#check AvailableChain.FGSA.fgsa_getHead_avoids_unsupported_child
#print axioms AvailableChain.FGSA.fgsa_getHead_avoids_unsupported_child
#check AvailableChain.FGSA.fgsa_getHead_covers_of_dominated_suffix
#print axioms AvailableChain.FGSA.fgsa_getHead_covers_of_dominated_suffix
#check AvailableChain.FGSA.fgsa_getHead_exact_of_dominated_suffix
#print axioms AvailableChain.FGSA.fgsa_getHead_exact_of_dominated_suffix
#check AvailableChain.FGSA.fgsa_getHead_reanchor_of_dominated_suffix
#print axioms AvailableChain.FGSA.fgsa_getHead_reanchor_of_dominated_suffix
#check AvailableChain.FGSA.fgsa_headInTree_covers_of_transfer
#print axioms AvailableChain.FGSA.fgsa_headInTree_covers_of_transfer
#check AvailableChain.FGSA.fgsa_headInTree_mem_or_anchor
#print axioms AvailableChain.FGSA.fgsa_headInTree_mem_or_anchor
#check AvailableChain.FGSA.fgsa_headInTree_noEligibleChild
#print axioms AvailableChain.FGSA.fgsa_headInTree_noEligibleChild
#check AvailableChain.FGSA.fgsa_headInTree_reanchor_of_pivot
#print axioms AvailableChain.FGSA.fgsa_headInTree_reanchor_of_pivot
#check AvailableChain.FGSA.fgsa_headVote_covers_of_transfer
#print axioms AvailableChain.FGSA.fgsa_headVote_covers_of_transfer
#check AvailableChain.FGSA.fgsa_prefixSupport_antitone
#print axioms AvailableChain.FGSA.fgsa_prefixSupport_antitone
#check AvailableChain.FGSA.fgsa_score_eq_on_retained_suffix
#print axioms AvailableChain.FGSA.fgsa_score_eq_on_retained_suffix
#check AvailableChain.FGSA.finalized_preceq_stable
#print axioms AvailableChain.FGSA.finalized_preceq_stable
#check AvailableChain.FGSA.foldRows_headDomain
#print axioms AvailableChain.FGSA.foldRows_headDomain
#check AvailableChain.FGSA.foldVotes_fields
#print axioms AvailableChain.FGSA.foldVotes_fields
#check AvailableChain.FGSA.foldVotes_headDomain
#print axioms AvailableChain.FGSA.foldVotes_headDomain
#check AvailableChain.FGSA.foldVotes_stamps
#print axioms AvailableChain.FGSA.foldVotes_stamps
#check AvailableChain.FGSA.foldVotes_withBlocks
#print axioms AvailableChain.FGSA.foldVotes_withBlocks
#check AvailableChain.FGSA.foldl_admitRow_view
#print axioms AvailableChain.FGSA.foldl_admitRow_view
#check AvailableChain.FGSA.freeze_blocks
#print axioms AvailableChain.FGSA.freeze_blocks
#check AvailableChain.FGSA.gateFrom_target_origin_slow
#print axioms AvailableChain.FGSA.gateFrom_target_origin_slow
#check AvailableChain.FGSA.gateStep_base_blocks
#print axioms AvailableChain.FGSA.gateStep_base_blocks
#check AvailableChain.FGSA.gateStep_fg
#print axioms AvailableChain.FGSA.gateStep_fg
#check AvailableChain.FGSA.gateStep_fresh
#print axioms AvailableChain.FGSA.gateStep_fresh
#check AvailableChain.FGSA.gateStep_nest
#print axioms AvailableChain.FGSA.gateStep_nest
#check AvailableChain.FGSA.gateStep_proposals
#print axioms AvailableChain.FGSA.gateStep_proposals
#check AvailableChain.FGSA.gateStep_rowPool
#print axioms AvailableChain.FGSA.gateStep_rowPool
#check AvailableChain.FGSA.gateStep_saved
#print axioms AvailableChain.FGSA.gateStep_saved
#check AvailableChain.FGSA.gateStep_stamps
#print axioms AvailableChain.FGSA.gateStep_stamps
#check AvailableChain.FGSA.getHead_stored
#print axioms AvailableChain.FGSA.getHead_stored
#check AvailableChain.FGSA.headInTree_stored
#print axioms AvailableChain.FGSA.headInTree_stored
#check AvailableChain.FGSA.headVote_stored
#print axioms AvailableChain.FGSA.headVote_stored
#check AvailableChain.FGSA.leaseBelowOutputStore_of_reachable
#print axioms AvailableChain.FGSA.leaseBelowOutputStore_of_reachable
#check AvailableChain.FGSA.leaseBelowOutputStore_of_storedTargetsBelowOutput
#print axioms AvailableChain.FGSA.leaseBelowOutputStore_of_storedTargetsBelowOutput
#check AvailableChain.FGSA.leaseOf_eq_deadlineOf
#print axioms AvailableChain.FGSA.leaseOf_eq_deadlineOf
#check AvailableChain.FGSA.liveRoot_preceq_headInTree
#print axioms AvailableChain.FGSA.liveRoot_preceq_headInTree
#check AvailableChain.FGSA.liveRoot_stored
#print axioms AvailableChain.FGSA.liveRoot_stored
#check AvailableChain.FGSA.mem_allBlockRows_iff
#print axioms AvailableChain.FGSA.mem_allBlockRows_iff
#check AvailableChain.FGSA.mem_genuine_of_saved
#print axioms AvailableChain.FGSA.mem_genuine_of_saved
#check AvailableChain.FGSA.mem_namedBodies
#print axioms AvailableChain.FGSA.mem_namedBodies
#check AvailableChain.FGSA.metaInv_accepted
#print axioms AvailableChain.FGSA.metaInv_accepted
#check AvailableChain.FGSA.metaInv_clock
#print axioms AvailableChain.FGSA.metaInv_clock
#check AvailableChain.FGSA.metaInv_init
#print axioms AvailableChain.FGSA.metaInv_init
#check AvailableChain.FGSA.metaInv_process
#print axioms AvailableChain.FGSA.metaInv_process
#check AvailableChain.FGSA.namedBodies_erase_domain
#print axioms AvailableChain.FGSA.namedBodies_erase_domain
#check AvailableChain.FGSA.namedBodies_erase_injective
#print axioms AvailableChain.FGSA.namedBodies_erase_injective
#check AvailableChain.FGSA.namedBodies_parent
#print axioms AvailableChain.FGSA.namedBodies_parent
#check AvailableChain.FGSA.namedBodies_root_injective
#print axioms AvailableChain.FGSA.namedBodies_root_injective
#check AvailableChain.FGSA.namedByErase?_complete
#print axioms AvailableChain.FGSA.namedByErase?_complete
#check AvailableChain.FGSA.namedByErase?_sound
#print axioms AvailableChain.FGSA.namedByErase?_sound
#check AvailableChain.FGSA.namedByErase?_stored
#print axioms AvailableChain.FGSA.namedByErase?_stored
#check AvailableChain.FGSA.namedProposal_erase
#print axioms AvailableChain.FGSA.namedProposal_erase
#check AvailableChain.FGSA.named_erase_ancestor
#print axioms AvailableChain.FGSA.named_erase_ancestor
#check AvailableChain.FGSA.named_erase_eq_genesis
#print axioms AvailableChain.FGSA.named_erase_eq_genesis
#check AvailableChain.FGSA.named_erase_parent
#print axioms AvailableChain.FGSA.named_erase_parent
#check AvailableChain.FGSA.named_erase_root
#print axioms AvailableChain.FGSA.named_erase_root
#check AvailableChain.FGSA.named_erase_slot
#print axioms AvailableChain.FGSA.named_erase_slot
#check AvailableChain.FGSA.named_preceq_erase
#print axioms AvailableChain.FGSA.named_preceq_erase
#check AvailableChain.FGSA.named_preceq_refl
#print axioms AvailableChain.FGSA.named_preceq_refl
#check AvailableChain.FGSA.named_preceq_trans
#print axioms AvailableChain.FGSA.named_preceq_trans
#check AvailableChain.FGSA.ne_of_saved
#print axioms AvailableChain.FGSA.ne_of_saved
#check AvailableChain.FGSA.normalizeS_fg
#print axioms AvailableChain.FGSA.normalizeS_fg
#check AvailableChain.FGSA.normalizeS_fields
#print axioms AvailableChain.FGSA.normalizeS_fields
#check AvailableChain.FGSA.normalizeS_nest
#print axioms AvailableChain.FGSA.normalizeS_nest
#check AvailableChain.FGSA.notMem_keys_of_unsaved
#print axioms AvailableChain.FGSA.notMem_keys_of_unsaved
#check AvailableChain.FGSA.onView_base_blocks
#print axioms AvailableChain.FGSA.onView_base_blocks
#check AvailableChain.FGSA.onView_fastWrite
#print axioms AvailableChain.FGSA.onView_fastWrite
#check AvailableChain.FGSA.onView_fg
#print axioms AvailableChain.FGSA.onView_fg
#check AvailableChain.FGSA.onView_onView
#print axioms AvailableChain.FGSA.onView_onView
#check AvailableChain.FGSA.onView_proposals
#print axioms AvailableChain.FGSA.onView_proposals
#check AvailableChain.FGSA.onView_rowPool
#print axioms AvailableChain.FGSA.onView_rowPool
#check AvailableChain.FGSA.outputNesting_stored
#print axioms AvailableChain.FGSA.outputNesting_stored
#check AvailableChain.FGSA.parentFG_isSome_iff_root
#print axioms AvailableChain.FGSA.parentFG_isSome_iff_root
#check AvailableChain.FGSA.preceq_fgHead_of_preceq_F
#print axioms AvailableChain.FGSA.preceq_fgHead_of_preceq_F
#check AvailableChain.FGSA.preceq_getHead_of_preceq_F
#print axioms AvailableChain.FGSA.preceq_getHead_of_preceq_F
#check AvailableChain.FGSA.process_cumulative
#print axioms AvailableChain.FGSA.process_cumulative
#check AvailableChain.FGSA.process_headDomain
#print axioms AvailableChain.FGSA.process_headDomain
#check AvailableChain.FGSA.process_nest
#print axioms AvailableChain.FGSA.process_nest
#check AvailableChain.FGSA.proposal?_eq_some
#print axioms AvailableChain.FGSA.proposal?_eq_some
#check AvailableChain.FGSA.proposalRowsFor_origin
#print axioms AvailableChain.FGSA.proposalRowsFor_origin
#check AvailableChain.FGSA.proposalRowsFor_perm
#print axioms AvailableChain.FGSA.proposalRowsFor_perm
#check AvailableChain.FGSA.propose_isSome_of_reachable
#print axioms AvailableChain.FGSA.propose_isSome_of_reachable
#check AvailableChain.FGSA.propose_parent_lookup
#print axioms AvailableChain.FGSA.propose_parent_lookup
#check AvailableChain.FGSA.propose_setEq
#print axioms AvailableChain.FGSA.propose_setEq
#check AvailableChain.FGSA.reachable_named_store
#print axioms AvailableChain.FGSA.reachable_named_store
#check AvailableChain.FGSA.reconcile_eq
#print axioms AvailableChain.FGSA.reconcile_eq
#check AvailableChain.FGSA.reconcile_fastOrigin
#print axioms AvailableChain.FGSA.reconcile_fastOrigin
#check AvailableChain.FGSA.reconcile_fastWrite
#print axioms AvailableChain.FGSA.reconcile_fastWrite
#check AvailableChain.FGSA.reconcile_fg
#print axioms AvailableChain.FGSA.reconcile_fg
#check AvailableChain.FGSA.reconcile_frame
#print axioms AvailableChain.FGSA.reconcile_frame
#check AvailableChain.FGSA.reconcile_genuine
#print axioms AvailableChain.FGSA.reconcile_genuine
#check AvailableChain.FGSA.reconcile_harmless
#print axioms AvailableChain.FGSA.reconcile_harmless
#check AvailableChain.FGSA.reconcile_harmless_origin
#print axioms AvailableChain.FGSA.reconcile_harmless_origin
#check AvailableChain.FGSA.reconcile_idem
#print axioms AvailableChain.FGSA.reconcile_idem
#check AvailableChain.FGSA.reconcile_nest
#print axioms AvailableChain.FGSA.reconcile_nest
#check AvailableChain.FGSA.reconcile_obligations
#print axioms AvailableChain.FGSA.reconcile_obligations
#check AvailableChain.FGSA.reconcile_saCompat
#print axioms AvailableChain.FGSA.reconcile_saCompat
#check AvailableChain.FGSA.reconcile_savedGenuine
#print axioms AvailableChain.FGSA.reconcile_savedGenuine
#check AvailableChain.FGSA.reconcile_stable
#print axioms AvailableChain.FGSA.reconcile_stable
#check AvailableChain.FGSA.release_blocks
#print axioms AvailableChain.FGSA.release_blocks
#check AvailableChain.FGSA.resolvedHead_mem
#print axioms AvailableChain.FGSA.resolvedHead_mem
#check AvailableChain.FGSA.rootInjectiveBelow_base
#print axioms AvailableChain.FGSA.rootInjectiveBelow_base
#check AvailableChain.FGSA.rootTest_iff_blockTest
#print axioms AvailableChain.FGSA.rootTest_iff_blockTest
#check AvailableChain.FGSA.rowsValidStored_admitBlock
#print axioms AvailableChain.FGSA.rowsValidStored_admitBlock
#check AvailableChain.FGSA.rowsValidStored_clock
#print axioms AvailableChain.FGSA.rowsValidStored_clock
#check AvailableChain.FGSA.rowsValidStored_initial
#print axioms AvailableChain.FGSA.rowsValidStored_initial
#check AvailableChain.FGSA.rowsValidStored_process
#print axioms AvailableChain.FGSA.rowsValidStored_process
#check AvailableChain.FGSA.saGateWriteKeys_level
#print axioms AvailableChain.FGSA.saGateWriteKeys_level
#check AvailableChain.FGSA.saGate_blocks
#print axioms AvailableChain.FGSA.saGate_blocks
#check AvailableChain.FGSA.saGate_cases
#print axioms AvailableChain.FGSA.saGate_cases
#check AvailableChain.FGSA.saGate_genuine
#print axioms AvailableChain.FGSA.saGate_genuine
#check AvailableChain.FGSA.saGate_stamps
#print axioms AvailableChain.FGSA.saGate_stamps
#check AvailableChain.FGSA.savedGenuine_append
#print axioms AvailableChain.FGSA.savedGenuine_append
#check AvailableChain.FGSA.savedGenuine_congr
#print axioms AvailableChain.FGSA.savedGenuine_congr
#check AvailableChain.FGSA.storeBundleInvariant
#print axioms AvailableChain.FGSA.storeBundleInvariant
#check AvailableChain.FGSA.storeStepRoots_of_blockAccepted
#print axioms AvailableChain.FGSA.storeStepRoots_of_blockAccepted
#check AvailableChain.FGSA.storedTargetsBelowOutput_clock
#print axioms AvailableChain.FGSA.storedTargetsBelowOutput_clock
#check AvailableChain.FGSA.storedTargetsBelowOutput_init
#print axioms AvailableChain.FGSA.storedTargetsBelowOutput_init
#check AvailableChain.FGSA.storedTargetsBelowOutput_process
#print axioms AvailableChain.FGSA.storedTargetsBelowOutput_process
#check AvailableChain.FGSA.storedTargetsBelowOutput_target
#print axioms AvailableChain.FGSA.storedTargetsBelowOutput_target
#check AvailableChain.FGSA.stored_wire_of_block
#print axioms AvailableChain.FGSA.stored_wire_of_block
#check AvailableChain.FGSA.wire_block_mem
#print axioms AvailableChain.FGSA.wire_block_mem
#check AvailableChain.FGSA.writeKeys_keys
#print axioms AvailableChain.FGSA.writeKeys_keys
#check AvailableChain.FGSA.writeKeys_stamps
#print axioms AvailableChain.FGSA.writeKeys_stamps
#check AvailableChain.FGSA.writeObligation_keys
#print axioms AvailableChain.FGSA.writeObligation_keys
#check AvailableChain.Gen.AC.ACReads.gateFast_def
#print axioms AvailableChain.Gen.AC.ACReads.gateFast_def
#check AvailableChain.Gen.AC.ACReads.gateLeases_def
#print axioms AvailableChain.Gen.AC.ACReads.gateLeases_def
#check AvailableChain.Gen.AC.ACReads.gatePrefixes_def
#print axioms AvailableChain.Gen.AC.ACReads.gatePrefixes_def
#check AvailableChain.Gen.AC.ACReads.gateView_def
#print axioms AvailableChain.Gen.AC.ACReads.gateView_def
#check AvailableChain.Gen.AC.BatchBounds_def
#print axioms AvailableChain.Gen.AC.BatchBounds_def
#check AvailableChain.Gen.AC.BatchCountsStatement_def
#print axioms AvailableChain.Gen.AC.BatchCountsStatement_def
#check AvailableChain.Gen.AC.BatchStatement_def
#print axioms AvailableChain.Gen.AC.BatchStatement_def
#check AvailableChain.Gen.AC.CapPairStatement_def
#print axioms AvailableChain.Gen.AC.CapPairStatement_def
#check AvailableChain.Gen.AC.CapVoteStatement_def
#print axioms AvailableChain.Gen.AC.CapVoteStatement_def
#check AvailableChain.Gen.AC.ConflictingScoreSumLeStatement_def
#print axioms AvailableChain.Gen.AC.ConflictingScoreSumLeStatement_def
#check AvailableChain.Gen.AC.Duty.ACLaws.anchor_le_output
#print axioms AvailableChain.Gen.AC.Duty.ACLaws.anchor_le_output
#check AvailableChain.Gen.AC.Duty.ACLaws.gate_write
#print axioms AvailableChain.Gen.AC.Duty.ACLaws.gate_write
#check AvailableChain.Gen.AC.Duty.ACLaws.lease_le_output
#print axioms AvailableChain.Gen.AC.Duty.ACLaws.lease_le_output
#check AvailableChain.Gen.AC.Duty.ACLaws.output_step
#print axioms AvailableChain.Gen.AC.Duty.ACLaws.output_step
#check AvailableChain.Gen.AC.Duty.ACReads.gateFast_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.gateFast_def
#check AvailableChain.Gen.AC.Duty.ACReads.gateLeases_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.gateLeases_def
#check AvailableChain.Gen.AC.Duty.ACReads.gateLevels_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.gateLevels_def
#check AvailableChain.Gen.AC.Duty.ACReads.gatePrefixes_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.gatePrefixes_def
#check AvailableChain.Gen.AC.Duty.ACReads.gateView_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.gateView_def
#check AvailableChain.Gen.AC.Duty.ACReads.saved_def
#print axioms AvailableChain.Gen.AC.Duty.ACReads.saved_def
#check AvailableChain.Gen.AC.Duty.GateOfCoveringBatchStatement_def
#print axioms AvailableChain.Gen.AC.Duty.GateOfCoveringBatchStatement_def
#check AvailableChain.Gen.AC.Duty.GateRunSpec.accept
#print axioms AvailableChain.Gen.AC.Duty.GateRunSpec.accept
#check AvailableChain.Gen.AC.Duty.GateRunSpec.empty
#print axioms AvailableChain.Gen.AC.Duty.GateRunSpec.empty
#check AvailableChain.Gen.AC.Duty.GateRunSpec.veto
#print axioms AvailableChain.Gen.AC.Duty.GateRunSpec.veto
#check AvailableChain.Gen.AC.Duty.GateService_def
#print axioms AvailableChain.Gen.AC.Duty.GateService_def
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.anchor_eq
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.anchor_eq
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.effects
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.effects
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.fresh
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.fresh
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.raw_eq
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.raw_eq
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.saved
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.saved
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.saved_other
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.saved_other
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_leases
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_leases
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_now
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_now
#check AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_output
#print axioms AvailableChain.Gen.AC.Duty.GateWriteAtSpec.view_output
#check AvailableChain.Gen.AC.Duty.GateWriteOfScheduleWellFormedStatement_def
#print axioms AvailableChain.Gen.AC.Duty.GateWriteOfScheduleWellFormedStatement_def
#check AvailableChain.Gen.AC.Duty.GateWriteSpec_def
#print axioms AvailableChain.Gen.AC.Duty.GateWriteSpec_def
#check AvailableChain.Gen.AC.Duty.GateWrite_def
#print axioms AvailableChain.Gen.AC.Duty.GateWrite_def
#check AvailableChain.Gen.AC.Duty.LeaseBelowOutput_def
#print axioms AvailableChain.Gen.AC.Duty.LeaseBelowOutput_def
#check AvailableChain.Gen.AC.Duty.Reconcile_def
#print axioms AvailableChain.Gen.AC.Duty.Reconcile_def
#check AvailableChain.Gen.AC.Duty.SEqOfExactStatement_def
#print axioms AvailableChain.Gen.AC.Duty.SEqOfExactStatement_def
#check AvailableChain.Gen.AC.Duty.S_eq_of_exact
#print axioms AvailableChain.Gen.AC.Duty.S_eq_of_exact
#check AvailableChain.Gen.AC.Duty.S_eq_of_exact_statement
#print axioms AvailableChain.Gen.AC.Duty.S_eq_of_exact_statement
#check AvailableChain.Gen.AC.Duty.gate_of_coveringBatch
#print axioms AvailableChain.Gen.AC.Duty.gate_of_coveringBatch
#check AvailableChain.Gen.AC.Duty.gate_of_coveringBatch_statement
#print axioms AvailableChain.Gen.AC.Duty.gate_of_coveringBatch_statement
#check AvailableChain.Gen.AC.ExpireByThresholdStatement_def
#print axioms AvailableChain.Gen.AC.ExpireByThresholdStatement_def
#check AvailableChain.Gen.AC.GateOfCoveringBatchStatement_def
#print axioms AvailableChain.Gen.AC.GateOfCoveringBatchStatement_def
#check AvailableChain.Gen.AC.GateRunSpec.accept
#print axioms AvailableChain.Gen.AC.GateRunSpec.accept
#check AvailableChain.Gen.AC.GateRunSpec.empty
#print axioms AvailableChain.Gen.AC.GateRunSpec.empty
#check AvailableChain.Gen.AC.GateRunSpec.veto
#print axioms AvailableChain.Gen.AC.GateRunSpec.veto
#check AvailableChain.Gen.AC.GateService_def
#print axioms AvailableChain.Gen.AC.GateService_def
#check AvailableChain.Gen.AC.GateWriteAtSpec.effects
#print axioms AvailableChain.Gen.AC.GateWriteAtSpec.effects
#check AvailableChain.Gen.AC.GateWriteAtSpec.view_leases
#print axioms AvailableChain.Gen.AC.GateWriteAtSpec.view_leases
#check AvailableChain.Gen.AC.GateWriteAtSpec.view_now
#print axioms AvailableChain.Gen.AC.GateWriteAtSpec.view_now
#check AvailableChain.Gen.AC.GateWriteAtSpec.view_output
#print axioms AvailableChain.Gen.AC.GateWriteAtSpec.view_output
#check AvailableChain.Gen.AC.GoldfishScoreAntitoneStatement_def
#print axioms AvailableChain.Gen.AC.GoldfishScoreAntitoneStatement_def
#check AvailableChain.Gen.AC.LeaseMapChain_def
#print axioms AvailableChain.Gen.AC.LeaseMapChain_def
#check AvailableChain.Gen.AC.ProtectsUntil_def
#print axioms AvailableChain.Gen.AC.ProtectsUntil_def
#check AvailableChain.Gen.AC.Root.BatchBounds_def
#print axioms AvailableChain.Gen.AC.Root.BatchBounds_def
#check AvailableChain.Gen.AC.Root.BatchCountsStatement_def
#print axioms AvailableChain.Gen.AC.Root.BatchCountsStatement_def
#check AvailableChain.Gen.AC.Root.BatchStatement_def
#print axioms AvailableChain.Gen.AC.Root.BatchStatement_def
#check AvailableChain.Gen.AC.Root.CapPairStatement_def
#print axioms AvailableChain.Gen.AC.Root.CapPairStatement_def
#check AvailableChain.Gen.AC.Root.CapVoteStatement_def
#print axioms AvailableChain.Gen.AC.Root.CapVoteStatement_def
#check AvailableChain.Gen.AC.Root.ConflictingScoreSumLeStatement_def
#print axioms AvailableChain.Gen.AC.Root.ConflictingScoreSumLeStatement_def
#check AvailableChain.Gen.AC.Root.GoldfishScoreAntitoneStatement_def
#print axioms AvailableChain.Gen.AC.Root.GoldfishScoreAntitoneStatement_def
#check AvailableChain.Gen.AC.Root.LeaseMapChain_def
#print axioms AvailableChain.Gen.AC.Root.LeaseMapChain_def
#check AvailableChain.Gen.AC.Root.ProtectsUntil_def
#print axioms AvailableChain.Gen.AC.Root.ProtectsUntil_def
#check AvailableChain.Gen.AC.Root.ScoreEqOnStatement_def
#print axioms AvailableChain.Gen.AC.Root.ScoreEqOnStatement_def
#check AvailableChain.Gen.AC.Root.TransferBounds_def
#print axioms AvailableChain.Gen.AC.Root.TransferBounds_def
#check AvailableChain.Gen.AC.Root.TransferN2Statement_def
#print axioms AvailableChain.Gen.AC.Root.TransferN2Statement_def
#check AvailableChain.Gen.AC.Root.TransferStatement_def
#print axioms AvailableChain.Gen.AC.Root.TransferStatement_def
#check AvailableChain.Gen.AC.Root.UniqueLeaseKeys_def
#print axioms AvailableChain.Gen.AC.Root.UniqueLeaseKeys_def
#check AvailableChain.Gen.AC.Root.VoterCountLeOfSeatsSubsetStatement_def
#print axioms AvailableChain.Gen.AC.Root.VoterCountLeOfSeatsSubsetStatement_def
#check AvailableChain.Gen.AC.Root.batch_anchored
#print axioms AvailableChain.Gen.AC.Root.batch_anchored
#check AvailableChain.Gen.AC.Root.batch_counts
#print axioms AvailableChain.Gen.AC.Root.batch_counts
#check AvailableChain.Gen.AC.Root.batch_counts_statement
#print axioms AvailableChain.Gen.AC.Root.batch_counts_statement
#check AvailableChain.Gen.AC.Root.cap_pair
#print axioms AvailableChain.Gen.AC.Root.cap_pair
#check AvailableChain.Gen.AC.Root.cap_pair_statement
#print axioms AvailableChain.Gen.AC.Root.cap_pair_statement
#check AvailableChain.Gen.AC.Root.cap_vote
#print axioms AvailableChain.Gen.AC.Root.cap_vote
#check AvailableChain.Gen.AC.Root.cap_vote_statement
#print axioms AvailableChain.Gen.AC.Root.cap_vote_statement
#check AvailableChain.Gen.AC.Root.conflicting_scoreOn_sum_le
#print axioms AvailableChain.Gen.AC.Root.conflicting_scoreOn_sum_le
#check AvailableChain.Gen.AC.Root.conflicting_score_sum_le
#print axioms AvailableChain.Gen.AC.Root.conflicting_score_sum_le
#check AvailableChain.Gen.AC.Root.conflicting_score_sum_le_statement
#print axioms AvailableChain.Gen.AC.Root.conflicting_score_sum_le_statement
#check AvailableChain.Gen.AC.Root.goldfishScoreOn_antitone
#print axioms AvailableChain.Gen.AC.Root.goldfishScoreOn_antitone
#check AvailableChain.Gen.AC.Root.goldfishScoreOn_le
#print axioms AvailableChain.Gen.AC.Root.goldfishScoreOn_le
#check AvailableChain.Gen.AC.Root.goldfishScore_antitone
#print axioms AvailableChain.Gen.AC.Root.goldfishScore_antitone
#check AvailableChain.Gen.AC.Root.goldfishScore_antitone_of_preceq
#print axioms AvailableChain.Gen.AC.Root.goldfishScore_antitone_of_preceq
#check AvailableChain.Gen.AC.Root.goldfishScore_antitone_statement
#print axioms AvailableChain.Gen.AC.Root.goldfishScore_antitone_statement
#check AvailableChain.Gen.AC.Root.plainSupporters_def
#print axioms AvailableChain.Gen.AC.Root.plainSupporters_def
#check AvailableChain.Gen.AC.Root.poolSupports_def
#print axioms AvailableChain.Gen.AC.Root.poolSupports_def
#check AvailableChain.Gen.AC.Root.resolvedTarget_transport
#print axioms AvailableChain.Gen.AC.Root.resolvedTarget_transport
#check AvailableChain.Gen.AC.Root.score_eq_on
#print axioms AvailableChain.Gen.AC.Root.score_eq_on
#check AvailableChain.Gen.AC.Root.score_eq_on_statement
#print axioms AvailableChain.Gen.AC.Root.score_eq_on_statement
#check AvailableChain.Gen.AC.Root.transfer
#print axioms AvailableChain.Gen.AC.Root.transfer
#check AvailableChain.Gen.AC.Root.transfer_n2
#print axioms AvailableChain.Gen.AC.Root.transfer_n2
#check AvailableChain.Gen.AC.Root.transfer_n2_statement
#print axioms AvailableChain.Gen.AC.Root.transfer_n2_statement
#check AvailableChain.Gen.AC.Root.transfer_statement
#print axioms AvailableChain.Gen.AC.Root.transfer_statement
#check AvailableChain.Gen.AC.Root.voteSupports_def
#print axioms AvailableChain.Gen.AC.Root.voteSupports_def
#check AvailableChain.Gen.AC.Root.vote_pool_clean_subset
#print axioms AvailableChain.Gen.AC.Root.vote_pool_clean_subset
#check AvailableChain.Gen.AC.Root.vote_pool_clean_unique
#print axioms AvailableChain.Gen.AC.Root.vote_pool_clean_unique
#check AvailableChain.Gen.AC.Root.vote_pool_equivocates_mono
#print axioms AvailableChain.Gen.AC.Root.vote_pool_equivocates_mono
#check AvailableChain.Gen.AC.Root.vote_pool_equivocates_participant
#print axioms AvailableChain.Gen.AC.Root.vote_pool_equivocates_participant
#check AvailableChain.Gen.AC.Root.vote_pool_eraseDups_nodup
#print axioms AvailableChain.Gen.AC.Root.vote_pool_eraseDups_nodup
#check AvailableChain.Gen.AC.Root.vote_pool_mem_seats
#print axioms AvailableChain.Gen.AC.Root.vote_pool_mem_seats
#check AvailableChain.Gen.AC.Root.vote_pool_plain_subset_score
#print axioms AvailableChain.Gen.AC.Root.vote_pool_plain_subset_score
#check AvailableChain.Gen.AC.Root.vote_pool_score_card
#print axioms AvailableChain.Gen.AC.Root.vote_pool_score_card
#check AvailableChain.Gen.AC.Root.vote_pool_seats_backward
#print axioms AvailableChain.Gen.AC.Root.vote_pool_seats_backward
#check AvailableChain.Gen.AC.Root.vote_pool_seats_subset
#print axioms AvailableChain.Gen.AC.Root.vote_pool_seats_subset
#check AvailableChain.Gen.AC.Root.vote_pool_support_ancestor
#print axioms AvailableChain.Gen.AC.Root.vote_pool_support_ancestor
#check AvailableChain.Gen.AC.Root.vote_pool_support_compatible
#print axioms AvailableChain.Gen.AC.Root.vote_pool_support_compatible
#check AvailableChain.Gen.AC.Root.vote_pool_support_conflict
#print axioms AvailableChain.Gen.AC.Root.vote_pool_support_conflict
#check AvailableChain.Gen.AC.Root.vote_pool_support_witness
#print axioms AvailableChain.Gen.AC.Root.vote_pool_support_witness
#check AvailableChain.Gen.AC.Root.vote_pool_voterCount_card
#print axioms AvailableChain.Gen.AC.Root.vote_pool_voterCount_card
#check AvailableChain.Gen.AC.Root.vote_support_body
#print axioms AvailableChain.Gen.AC.Root.vote_support_body
#check AvailableChain.Gen.AC.Root.voterCount_le_of_seats_subset
#print axioms AvailableChain.Gen.AC.Root.voterCount_le_of_seats_subset
#check AvailableChain.Gen.AC.Root.voterCount_le_of_seats_subset_statement
#print axioms AvailableChain.Gen.AC.Root.voterCount_le_of_seats_subset_statement
#check AvailableChain.Gen.AC.SEqOfExactStatement_def
#print axioms AvailableChain.Gen.AC.SEqOfExactStatement_def
#check AvailableChain.Gen.AC.S_eq_of_exact
#print axioms AvailableChain.Gen.AC.S_eq_of_exact
#check AvailableChain.Gen.AC.S_eq_of_exact_statement
#print axioms AvailableChain.Gen.AC.S_eq_of_exact_statement
#check AvailableChain.Gen.AC.ScoreEqOnStatement_def
#print axioms AvailableChain.Gen.AC.ScoreEqOnStatement_def
#check AvailableChain.Gen.AC.TransferBounds_def
#print axioms AvailableChain.Gen.AC.TransferBounds_def
#check AvailableChain.Gen.AC.TransferN2Statement_def
#print axioms AvailableChain.Gen.AC.TransferN2Statement_def
#check AvailableChain.Gen.AC.TransferStatement_def
#print axioms AvailableChain.Gen.AC.TransferStatement_def
#check AvailableChain.Gen.AC.UniqueLeaseKeys_def
#print axioms AvailableChain.Gen.AC.UniqueLeaseKeys_def
#check AvailableChain.Gen.AC.VoterCountLeOfSeatsSubsetStatement_def
#print axioms AvailableChain.Gen.AC.VoterCountLeOfSeatsSubsetStatement_def
#check AvailableChain.Gen.AC.batch_anchored
#print axioms AvailableChain.Gen.AC.batch_anchored
#check AvailableChain.Gen.AC.batch_counts_statement
#print axioms AvailableChain.Gen.AC.batch_counts_statement
#check AvailableChain.Gen.AC.cap_pair_statement
#print axioms AvailableChain.Gen.AC.cap_pair_statement
#check AvailableChain.Gen.AC.cap_vote_statement
#print axioms AvailableChain.Gen.AC.cap_vote_statement
#check AvailableChain.Gen.AC.conflicting_score_sum_le
#print axioms AvailableChain.Gen.AC.conflicting_score_sum_le
#check AvailableChain.Gen.AC.conflicting_score_sum_le_statement
#print axioms AvailableChain.Gen.AC.conflicting_score_sum_le_statement
#check AvailableChain.Gen.AC.deadlineOf_eq_of_lease_row
#print axioms AvailableChain.Gen.AC.deadlineOf_eq_of_lease_row
#check AvailableChain.Gen.AC.expire_by_threshold_statement
#print axioms AvailableChain.Gen.AC.expire_by_threshold_statement
#check AvailableChain.Gen.AC.expire_protectsUntil
#print axioms AvailableChain.Gen.AC.expire_protectsUntil
#check AvailableChain.Gen.AC.gateWrite_of_scheduleWellFormed_statement
#print axioms AvailableChain.Gen.AC.gateWrite_of_scheduleWellFormed_statement
#check AvailableChain.Gen.AC.gate_of_coveringBatch
#print axioms AvailableChain.Gen.AC.gate_of_coveringBatch
#check AvailableChain.Gen.AC.gate_of_coveringBatch_statement
#print axioms AvailableChain.Gen.AC.gate_of_coveringBatch_statement
#check AvailableChain.Gen.AC.goldfishScore_antitone
#print axioms AvailableChain.Gen.AC.goldfishScore_antitone
#check AvailableChain.Gen.AC.goldfishScore_antitone_of_preceq
#print axioms AvailableChain.Gen.AC.goldfishScore_antitone_of_preceq
#check AvailableChain.Gen.AC.goldfishScore_antitone_statement
#print axioms AvailableChain.Gen.AC.goldfishScore_antitone_statement
#check AvailableChain.Gen.AC.pendingGate_harmless_statement
#print axioms AvailableChain.Gen.AC.pendingGate_harmless_statement
#check AvailableChain.Gen.AC.plainSupporters_def
#print axioms AvailableChain.Gen.AC.plainSupporters_def
#check AvailableChain.Gen.AC.poolSupports_def
#print axioms AvailableChain.Gen.AC.poolSupports_def
#check AvailableChain.Gen.AC.release_of_supporters
#print axioms AvailableChain.Gen.AC.release_of_supporters
#check AvailableChain.Gen.AC.release_protectsUntil
#print axioms AvailableChain.Gen.AC.release_protectsUntil
#check AvailableChain.Gen.AC.score_eq_on_statement
#print axioms AvailableChain.Gen.AC.score_eq_on_statement
#check AvailableChain.Gen.AC.transfer_n2_statement
#print axioms AvailableChain.Gen.AC.transfer_n2_statement
#check AvailableChain.Gen.AC.transfer_statement
#print axioms AvailableChain.Gen.AC.transfer_statement
#check AvailableChain.Gen.AC.voteSupports_def
#print axioms AvailableChain.Gen.AC.voteSupports_def
#check AvailableChain.Gen.AC.vote_pool_clean_subset
#print axioms AvailableChain.Gen.AC.vote_pool_clean_subset
#check AvailableChain.Gen.AC.vote_pool_clean_unique
#print axioms AvailableChain.Gen.AC.vote_pool_clean_unique
#check AvailableChain.Gen.AC.vote_pool_equivocates_mono
#print axioms AvailableChain.Gen.AC.vote_pool_equivocates_mono
#check AvailableChain.Gen.AC.vote_pool_equivocates_participant
#print axioms AvailableChain.Gen.AC.vote_pool_equivocates_participant
#check AvailableChain.Gen.AC.vote_pool_mem_seats
#print axioms AvailableChain.Gen.AC.vote_pool_mem_seats
#check AvailableChain.Gen.AC.vote_pool_plain_subset_score
#print axioms AvailableChain.Gen.AC.vote_pool_plain_subset_score
#check AvailableChain.Gen.AC.vote_pool_score_card
#print axioms AvailableChain.Gen.AC.vote_pool_score_card
#check AvailableChain.Gen.AC.vote_pool_seats_backward
#print axioms AvailableChain.Gen.AC.vote_pool_seats_backward
#check AvailableChain.Gen.AC.vote_pool_seats_subset
#print axioms AvailableChain.Gen.AC.vote_pool_seats_subset
#check AvailableChain.Gen.AC.vote_pool_support_ancestor
#print axioms AvailableChain.Gen.AC.vote_pool_support_ancestor
#check AvailableChain.Gen.AC.vote_pool_support_compatible
#print axioms AvailableChain.Gen.AC.vote_pool_support_compatible
#check AvailableChain.Gen.AC.vote_pool_support_conflict
#print axioms AvailableChain.Gen.AC.vote_pool_support_conflict
#check AvailableChain.Gen.AC.vote_pool_support_witness
#print axioms AvailableChain.Gen.AC.vote_pool_support_witness
#check AvailableChain.Gen.AC.vote_pool_voterCount_card
#print axioms AvailableChain.Gen.AC.vote_pool_voterCount_card
#check AvailableChain.Gen.AC.voterCount_le_of_seats_subset
#print axioms AvailableChain.Gen.AC.voterCount_le_of_seats_subset
#check AvailableChain.Gen.AC.voterCount_le_of_seats_subset_statement
#print axioms AvailableChain.Gen.AC.voterCount_le_of_seats_subset_statement
#check AvailableChain.Gen.AC.write_protectsUntil
#print axioms AvailableChain.Gen.AC.write_protectsUntil
#check AvailableChain.Gen.AC.write_unique_keys
#print axioms AvailableChain.Gen.AC.write_unique_keys
#check AvailableChain.GridCO.Legacy.act_embed
#print axioms AvailableChain.GridCO.Legacy.act_embed
#check AvailableChain.GridCO.Legacy.admissionLevels_embed
#print axioms AvailableChain.GridCO.Legacy.admissionLevels_embed
#check AvailableChain.GridCO.Legacy.admitProposal_embed
#print axioms AvailableChain.GridCO.Legacy.admitProposal_embed
#check AvailableChain.GridCO.Legacy.admitVote_embed
#print axioms AvailableChain.GridCO.Legacy.admitVote_embed
#check AvailableChain.GridCO.Legacy.carriedRaw_embed
#print axioms AvailableChain.GridCO.Legacy.carriedRaw_embed
#check AvailableChain.GridCO.Legacy.carriedSupport_embed
#print axioms AvailableChain.GridCO.Legacy.carriedSupport_embed
#check AvailableChain.GridCO.Legacy.cleanSupport_embed
#print axioms AvailableChain.GridCO.Legacy.cleanSupport_embed
#check AvailableChain.GridCO.Legacy.clockFrom_embed
#print axioms AvailableChain.GridCO.Legacy.clockFrom_embed
#check AvailableChain.GridCO.Legacy.clock_embed
#print axioms AvailableChain.GridCO.Legacy.clock_embed
#check AvailableChain.GridCO.Legacy.clock_eq_from_genesis
#print axioms AvailableChain.GridCO.Legacy.clock_eq_from_genesis
#check AvailableChain.GridCO.Legacy.confirmationFrom_embed
#print axioms AvailableChain.GridCO.Legacy.confirmationFrom_embed
#check AvailableChain.GridCO.Legacy.confirmation_eq_from_genesis
#print axioms AvailableChain.GridCO.Legacy.confirmation_eq_from_genesis
#check AvailableChain.GridCO.Legacy.deliveries_embed
#print axioms AvailableChain.GridCO.Legacy.deliveries_embed
#check AvailableChain.GridCO.Legacy.duties_nodup
#print axioms AvailableChain.GridCO.Legacy.duties_nodup
#check AvailableChain.GridCO.Legacy.duties_spec
#print axioms AvailableChain.GridCO.Legacy.duties_spec
#check AvailableChain.GridCO.Legacy.earlyVotes_embed
#print axioms AvailableChain.GridCO.Legacy.earlyVotes_embed
#check AvailableChain.GridCO.Legacy.embed_early
#print axioms AvailableChain.GridCO.Legacy.embed_early
#check AvailableChain.GridCO.Legacy.embed_ite
#print axioms AvailableChain.GridCO.Legacy.embed_ite
#check AvailableChain.GridCO.Legacy.embed_now
#print axioms AvailableChain.GridCO.Legacy.embed_now
#check AvailableChain.GridCO.Legacy.equivocates_block
#print axioms AvailableChain.GridCO.Legacy.equivocates_block
#check AvailableChain.GridCO.Legacy.event_fold_embed
#print axioms AvailableChain.GridCO.Legacy.event_fold_embed
#check AvailableChain.GridCO.Legacy.excludes_embed
#print axioms AvailableChain.GridCO.Legacy.excludes_embed
#check AvailableChain.GridCO.Legacy.expire_embed
#print axioms AvailableChain.GridCO.Legacy.expire_embed
#check AvailableChain.GridCO.Legacy.forkChoice_embed
#print axioms AvailableChain.GridCO.Legacy.forkChoice_embed
#check AvailableChain.GridCO.Legacy.freeze_embed
#print axioms AvailableChain.GridCO.Legacy.freeze_embed
#check AvailableChain.GridCO.Legacy.frozenAt_embed
#print axioms AvailableChain.GridCO.Legacy.frozenAt_embed
#check AvailableChain.GridCO.Legacy.gateFrom_embed
#print axioms AvailableChain.GridCO.Legacy.gateFrom_embed
#check AvailableChain.GridCO.Legacy.gate_eq_from_genesis
#print axioms AvailableChain.GridCO.Legacy.gate_eq_from_genesis
#check AvailableChain.GridCO.Legacy.goldfishEligible_block
#print axioms AvailableChain.GridCO.Legacy.goldfishEligible_block
#check AvailableChain.GridCO.Legacy.goldfishScore_block
#print axioms AvailableChain.GridCO.Legacy.goldfishScore_block
#check AvailableChain.GridCO.Legacy.headLabel_block
#print axioms AvailableChain.GridCO.Legacy.headLabel_block
#check AvailableChain.GridCO.Legacy.headSeat_block
#print axioms AvailableChain.GridCO.Legacy.headSeat_block
#check AvailableChain.GridCO.Legacy.headTarget_block
#print axioms AvailableChain.GridCO.Legacy.headTarget_block
#check AvailableChain.GridCO.Legacy.lateVotes_embed
#print axioms AvailableChain.GridCO.Legacy.lateVotes_embed
#check AvailableChain.GridCO.Legacy.liveRoot_embed
#print axioms AvailableChain.GridCO.Legacy.liveRoot_embed
#check AvailableChain.GridCO.Legacy.prefixSupport_embed
#print axioms AvailableChain.GridCO.Legacy.prefixSupport_embed
#check AvailableChain.GridCO.Legacy.process_embed
#print axioms AvailableChain.GridCO.Legacy.process_embed
#check AvailableChain.GridCO.Legacy.proposalsAt_embed
#print axioms AvailableChain.GridCO.Legacy.proposalsAt_embed
#check AvailableChain.GridCO.Legacy.propose_embed
#print axioms AvailableChain.GridCO.Legacy.propose_embed
#check AvailableChain.GridCO.Legacy.proposerSupportView_embed
#print axioms AvailableChain.GridCO.Legacy.proposerSupportView_embed
#check AvailableChain.GridCO.Legacy.proposerView_embed
#print axioms AvailableChain.GridCO.Legacy.proposerView_embed
#check AvailableChain.GridCO.Legacy.recordGenuine_embed
#print axioms AvailableChain.GridCO.Legacy.recordGenuine_embed
#check AvailableChain.GridCO.Legacy.releaseCount_embed
#print axioms AvailableChain.GridCO.Legacy.releaseCount_embed
#check AvailableChain.GridCO.Legacy.release_embed
#print axioms AvailableChain.GridCO.Legacy.release_embed
#check AvailableChain.GridCO.Legacy.resolvedBefore_embed
#print axioms AvailableChain.GridCO.Legacy.resolvedBefore_embed
#check AvailableChain.GridCO.Legacy.resolvedHead_embed
#print axioms AvailableChain.GridCO.Legacy.resolvedHead_embed
#check AvailableChain.GridCO.Legacy.resolvedHead_of_before
#print axioms AvailableChain.GridCO.Legacy.resolvedHead_of_before
#check AvailableChain.GridCO.Legacy.sameSeat_block
#print axioms AvailableChain.GridCO.Legacy.sameSeat_block
#check AvailableChain.GridCO.Legacy.savedGenuine_embed
#print axioms AvailableChain.GridCO.Legacy.savedGenuine_embed
#check AvailableChain.GridCO.Legacy.seatVotes_block
#print axioms AvailableChain.GridCO.Legacy.seatVotes_block
#check AvailableChain.GridCO.Legacy.seats_block
#print axioms AvailableChain.GridCO.Legacy.seats_block
#check AvailableChain.GridCO.Legacy.slotsAt_nodup
#print axioms AvailableChain.GridCO.Legacy.slotsAt_nodup
#check AvailableChain.GridCO.Legacy.slotsAt_spec
#print axioms AvailableChain.GridCO.Legacy.slotsAt_spec
#check AvailableChain.GridCO.Legacy.slowEligible_embed
#print axioms AvailableChain.GridCO.Legacy.slowEligible_embed
#check AvailableChain.GridCO.Legacy.stampBlock_embed
#print axioms AvailableChain.GridCO.Legacy.stampBlock_embed
#check AvailableChain.GridCO.Legacy.stampVote_embed
#print axioms AvailableChain.GridCO.Legacy.stampVote_embed
#check AvailableChain.GridCO.Legacy.toHead_block
#print axioms AvailableChain.GridCO.Legacy.toHead_block
#check AvailableChain.GridCO.Legacy.voterCount_block
#print axioms AvailableChain.GridCO.Legacy.voterCount_block
#check AvailableChain.GridCO.Legacy.voterSupportView_embed
#print axioms AvailableChain.GridCO.Legacy.voterSupportView_embed
#check AvailableChain.GridCO.Legacy.voterTree_embed
#print axioms AvailableChain.GridCO.Legacy.voterTree_embed
#check AvailableChain.GridCO.Legacy.voterView_embed
#print axioms AvailableChain.GridCO.Legacy.voterView_embed
#check AvailableChain.GridCO.Legacy.votesAt_embed
#print axioms AvailableChain.GridCO.Legacy.votesAt_embed
#check AvailableChain.GridCO.Legacy.votes_fold_embed
#print axioms AvailableChain.GridCO.Legacy.votes_fold_embed
#check AvailableChain.GridCO.Legacy.world_step_embed
#print axioms AvailableChain.GridCO.Legacy.world_step_embed
#check AvailableChain.GridCO.Legacy.writeObligation_embed
#print axioms AvailableChain.GridCO.Legacy.writeObligation_embed
#check AvailableChain.GridCO.MapReachable.aligned
#print axioms AvailableChain.GridCO.MapReachable.aligned
#check AvailableChain.GridCO.MapReachable.blocks
#print axioms AvailableChain.GridCO.MapReachable.blocks
#check AvailableChain.GridCO.MapReachable.comparable
#print axioms AvailableChain.GridCO.MapReachable.comparable
#check AvailableChain.GridCO.MapReachable.horizon
#print axioms AvailableChain.GridCO.MapReachable.horizon
#check AvailableChain.GridCO.MapReachable.liveRows
#print axioms AvailableChain.GridCO.MapReachable.liveRows
#check AvailableChain.GridCO.MapReachable.prefixOrder
#print axioms AvailableChain.GridCO.MapReachable.prefixOrder
#check AvailableChain.GridCO.ProposalViewTransport.count
#print axioms AvailableChain.GridCO.ProposalViewTransport.count
#check AvailableChain.GridCO.ProposalViewTransport.of_sets
#print axioms AvailableChain.GridCO.ProposalViewTransport.of_sets
#check AvailableChain.GridCO.ProposalViewTransport.score
#print axioms AvailableChain.GridCO.ProposalViewTransport.score
#check AvailableChain.GridCO.ProposalViewTransport.tree
#print axioms AvailableChain.GridCO.ProposalViewTransport.tree
#check AvailableChain.GridCO.ReceiptPrefix.blockStamp
#print axioms AvailableChain.GridCO.ReceiptPrefix.blockStamp
#check AvailableChain.GridCO.ReceiptPrefix.blocks
#print axioms AvailableChain.GridCO.ReceiptPrefix.blocks
#check AvailableChain.GridCO.ReceiptPrefix.refl
#print axioms AvailableChain.GridCO.ReceiptPrefix.refl
#check AvailableChain.GridCO.ReceiptPrefix.stampBlock
#print axioms AvailableChain.GridCO.ReceiptPrefix.stampBlock
#check AvailableChain.GridCO.ReceiptPrefix.stampVote
#print axioms AvailableChain.GridCO.ReceiptPrefix.stampVote
#check AvailableChain.GridCO.ReceiptPrefix.trans
#print axioms AvailableChain.GridCO.ReceiptPrefix.trans
#check AvailableChain.GridCO.ReceiptPrefix.voteStamp
#print axioms AvailableChain.GridCO.ReceiptPrefix.voteStamp
#check AvailableChain.GridCO.ReceiptPrefix.votes
#print axioms AvailableChain.GridCO.ReceiptPrefix.votes
#check AvailableChain.GridCO.ScorePreservingViewExtension.count_eq
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.count_eq
#check AvailableChain.GridCO.ScorePreservingViewExtension.eligible_eq
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.eligible_eq
#check AvailableChain.GridCO.ScorePreservingViewExtension.equivocates_eq
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.equivocates_eq
#check AvailableChain.GridCO.ScorePreservingViewExtension.raw_back
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.raw_back
#check AvailableChain.GridCO.ScorePreservingViewExtension.raw_subset
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.raw_subset
#check AvailableChain.GridCO.ScorePreservingViewExtension.score_eq
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.score_eq
#check AvailableChain.GridCO.ScorePreservingViewExtension.seats_eq
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.seats_eq
#check AvailableChain.GridCO.ScorePreservingViewExtension.support_back
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.support_back
#check AvailableChain.GridCO.ScorePreservingViewExtension.support_subset
#print axioms AvailableChain.GridCO.ScorePreservingViewExtension.support_subset
#check AvailableChain.GridCO.StampsBounded.stampBlock_le
#print axioms AvailableChain.GridCO.StampsBounded.stampBlock_le
#check AvailableChain.GridCO.StampsBounded.stampVote_le
#print axioms AvailableChain.GridCO.StampsBounded.stampVote_le
#check AvailableChain.GridCO.TransferReceipts.backward
#print axioms AvailableChain.GridCO.TransferReceipts.backward
#check AvailableChain.GridCO.TransferReceipts.conflict_disjoint
#print axioms AvailableChain.GridCO.TransferReceipts.conflict_disjoint
#check AvailableChain.GridCO.TransferReceipts.conflicting_score_bound
#print axioms AvailableChain.GridCO.TransferReceipts.conflicting_score_bound
#check AvailableChain.GridCO.TransferReceipts.forward
#print axioms AvailableChain.GridCO.TransferReceipts.forward
#check AvailableChain.GridCO.TransferReceipts.majority
#print axioms AvailableChain.GridCO.TransferReceipts.majority
#check AvailableChain.GridCO.TransferReceipts.participants_subset
#print axioms AvailableChain.GridCO.TransferReceipts.participants_subset
#check AvailableChain.GridCO.TransferReceipts.seat_unique
#print axioms AvailableChain.GridCO.TransferReceipts.seat_unique
#check AvailableChain.GridCO.TransferReceipts.support_raw
#print axioms AvailableChain.GridCO.TransferReceipts.support_raw
#check AvailableChain.GridCO.TransferReceipts.supporters_subset
#print axioms AvailableChain.GridCO.TransferReceipts.supporters_subset
#check AvailableChain.GridCO.accepted_block_before_ready_proposal
#print axioms AvailableChain.GridCO.accepted_block_before_ready_proposal
#check AvailableChain.GridCO.accepted_head_receipt_before
#print axioms AvailableChain.GridCO.accepted_head_receipt_before
#check AvailableChain.GridCO.accepted_head_time_lower
#print axioms AvailableChain.GridCO.accepted_head_time_lower
#check AvailableChain.GridCO.accepted_proposal_handled_stored
#print axioms AvailableChain.GridCO.accepted_proposal_handled_stored
#check AvailableChain.GridCO.admissionLevels_mono
#print axioms AvailableChain.GridCO.admissionLevels_mono
#check AvailableChain.GridCO.admissionLevels_preGate
#print axioms AvailableChain.GridCO.admissionLevels_preGate
#check AvailableChain.GridCO.admitProposal_blocks_ordered
#print axioms AvailableChain.GridCO.admitProposal_blocks_ordered
#check AvailableChain.GridCO.admitProposal_missingParent
#print axioms AvailableChain.GridCO.admitProposal_missingParent
#check AvailableChain.GridCO.admitProposal_now
#print axioms AvailableChain.GridCO.admitProposal_now
#check AvailableChain.GridCO.admitProposal_obligations
#print axioms AvailableChain.GridCO.admitProposal_obligations
#check AvailableChain.GridCO.admitProposal_receiptPrefix
#print axioms AvailableChain.GridCO.admitProposal_receiptPrefix
#check AvailableChain.GridCO.admitProposal_stamped
#print axioms AvailableChain.GridCO.admitProposal_stamped
#check AvailableChain.GridCO.admitProposal_stampsBounded
#print axioms AvailableChain.GridCO.admitProposal_stampsBounded
#check AvailableChain.GridCO.admitProposal_stored_prefix_closed
#print axioms AvailableChain.GridCO.admitProposal_stored_prefix_closed
#check AvailableChain.GridCO.admitVote_blocks
#print axioms AvailableChain.GridCO.admitVote_blocks
#check AvailableChain.GridCO.admitVote_head_mem_or_equivocates
#print axioms AvailableChain.GridCO.admitVote_head_mem_or_equivocates
#check AvailableChain.GridCO.admitVote_mem_origin
#print axioms AvailableChain.GridCO.admitVote_mem_origin
#check AvailableChain.GridCO.admitVote_new_head_label
#print axioms AvailableChain.GridCO.admitVote_new_head_label
#check AvailableChain.GridCO.admitVote_now
#print axioms AvailableChain.GridCO.admitVote_now
#check AvailableChain.GridCO.admitVote_obligations
#print axioms AvailableChain.GridCO.admitVote_obligations
#check AvailableChain.GridCO.admitVote_receiptPrefix
#print axioms AvailableChain.GridCO.admitVote_receiptPrefix
#check AvailableChain.GridCO.admitVote_stable
#print axioms AvailableChain.GridCO.admitVote_stable
#check AvailableChain.GridCO.admitVote_stamped
#print axioms AvailableChain.GridCO.admitVote_stamped
#check AvailableChain.GridCO.admitVote_stampsBounded
#print axioms AvailableChain.GridCO.admitVote_stampsBounded
#check AvailableChain.GridCO.admitVote_stored_prefix_closed
#print axioms AvailableChain.GridCO.admitVote_stored_prefix_closed
#check AvailableChain.GridCO.admitVote_votes_subset
#print axioms AvailableChain.GridCO.admitVote_votes_subset
#check AvailableChain.GridCO.admittedSources_of_gridSources
#print axioms AvailableChain.GridCO.admittedSources_of_gridSources
#check AvailableChain.GridCO.armingHeadsCompatible_of_clean
#print axioms AvailableChain.GridCO.armingHeadsCompatible_of_clean
#check AvailableChain.GridCO.armingHeadsCompatible_of_heads
#print axioms AvailableChain.GridCO.armingHeadsCompatible_of_heads
#check AvailableChain.GridCO.armingHeadsCompatible_of_protection
#print axioms AvailableChain.GridCO.armingHeadsCompatible_of_protection
#check AvailableChain.GridCO.blockKnown_parent_slot_iff_root
#print axioms AvailableChain.GridCO.blockKnown_parent_slot_iff_root
#check AvailableChain.GridCO.cleanSupport_eq_of_late_same_seat
#print axioms AvailableChain.GridCO.cleanSupport_eq_of_late_same_seat
#check AvailableChain.GridCO.cleanSupport_no_equivocation
#print axioms AvailableChain.GridCO.cleanSupport_no_equivocation
#check AvailableChain.GridCO.cleanSupport_not_equivocating
#print axioms AvailableChain.GridCO.cleanSupport_not_equivocating
#check AvailableChain.GridCO.cleanSupport_seat_unique
#print axioms AvailableChain.GridCO.cleanSupport_seat_unique
#check AvailableChain.GridCO.clean_gate_guard
#print axioms AvailableChain.GridCO.clean_gate_guard
#check AvailableChain.GridCO.clean_gate_reads_compatible
#print axioms AvailableChain.GridCO.clean_gate_reads_compatible
#check AvailableChain.GridCO.clean_gate_record_monotone
#print axioms AvailableChain.GridCO.clean_gate_record_monotone
#check AvailableChain.GridCO.clean_gate_record_prefix
#print axioms AvailableChain.GridCO.clean_gate_record_prefix
#check AvailableChain.GridCO.clean_genuine_history
#print axioms AvailableChain.GridCO.clean_genuine_history
#check AvailableChain.GridCO.clean_genuine_prefix
#print axioms AvailableChain.GridCO.clean_genuine_prefix
#check AvailableChain.GridCO.clean_history_at_ordinary_proposal
#print axioms AvailableChain.GridCO.clean_history_at_ordinary_proposal
#check AvailableChain.GridCO.clean_honest_proposal_heads
#print axioms AvailableChain.GridCO.clean_honest_proposal_heads
#check AvailableChain.GridCO.clean_honest_proposal_repair
#print axioms AvailableChain.GridCO.clean_honest_proposal_repair
#check AvailableChain.GridCO.clean_proposal_parent_ordinary
#print axioms AvailableChain.GridCO.clean_proposal_parent_ordinary
#check AvailableChain.GridCO.clean_roots_at_ordinary_proposal
#print axioms AvailableChain.GridCO.clean_roots_at_ordinary_proposal
#check AvailableChain.GridCO.clean_stable_heads_cover
#print axioms AvailableChain.GridCO.clean_stable_heads_cover
#check AvailableChain.GridCO.clockPreGate_deadlines_aligned
#print axioms AvailableChain.GridCO.clockPreGate_deadlines_aligned
#check AvailableChain.GridCO.clockPreGate_genuine
#print axioms AvailableChain.GridCO.clockPreGate_genuine
#check AvailableChain.GridCO.clockPreGate_invariants
#print axioms AvailableChain.GridCO.clockPreGate_invariants
#check AvailableChain.GridCO.clockPreGate_live_rows
#print axioms AvailableChain.GridCO.clockPreGate_live_rows
#check AvailableChain.GridCO.clockPreGate_obligations_subset
#print axioms AvailableChain.GridCO.clockPreGate_obligations_subset
#check AvailableChain.GridCO.clockPreGate_protectsUntil
#print axioms AvailableChain.GridCO.clockPreGate_protectsUntil
#check AvailableChain.GridCO.clockPreGate_receiptData
#print axioms AvailableChain.GridCO.clockPreGate_receiptData
#check AvailableChain.GridCO.clockPreGate_stable
#print axioms AvailableChain.GridCO.clockPreGate_stable
#check AvailableChain.GridCO.clock_at_gate
#print axioms AvailableChain.GridCO.clock_at_gate
#check AvailableChain.GridCO.clock_blocks
#print axioms AvailableChain.GridCO.clock_blocks
#check AvailableChain.GridCO.clock_deadline_horizon
#print axioms AvailableChain.GridCO.clock_deadline_horizon
#check AvailableChain.GridCO.clock_deadlines_aligned
#print axioms AvailableChain.GridCO.clock_deadlines_aligned
#check AvailableChain.GridCO.clock_eq_from_genesis
#print axioms AvailableChain.GridCO.clock_eq_from_genesis
#check AvailableChain.GridCO.clock_eq_gate_prestate
#print axioms AvailableChain.GridCO.clock_eq_gate_prestate
#check AvailableChain.GridCO.clock_frozen
#print axioms AvailableChain.GridCO.clock_frozen
#check AvailableChain.GridCO.clock_frozenAt_of_some
#print axioms AvailableChain.GridCO.clock_frozenAt_of_some
#check AvailableChain.GridCO.clock_genuine_origin
#print axioms AvailableChain.GridCO.clock_genuine_origin
#check AvailableChain.GridCO.clock_genuine_subset
#print axioms AvailableChain.GridCO.clock_genuine_subset
#check AvailableChain.GridCO.clock_input_row_admitted_origin
#print axioms AvailableChain.GridCO.clock_input_row_admitted_origin
#check AvailableChain.GridCO.clock_live_rows
#print axioms AvailableChain.GridCO.clock_live_rows
#check AvailableChain.GridCO.clock_map_invariants
#print axioms AvailableChain.GridCO.clock_map_invariants
#check AvailableChain.GridCO.clock_map_reachable
#print axioms AvailableChain.GridCO.clock_map_reachable
#check AvailableChain.GridCO.clock_now
#print axioms AvailableChain.GridCO.clock_now
#check AvailableChain.GridCO.clock_preserves_protection
#print axioms AvailableChain.GridCO.clock_preserves_protection
#check AvailableChain.GridCO.clock_proposals
#print axioms AvailableChain.GridCO.clock_proposals
#check AvailableChain.GridCO.clock_receiptData
#print axioms AvailableChain.GridCO.clock_receiptData
#check AvailableChain.GridCO.clock_recordSlotOrdered
#print axioms AvailableChain.GridCO.clock_recordSlotOrdered
#check AvailableChain.GridCO.clock_release_obligations
#print axioms AvailableChain.GridCO.clock_release_obligations
#check AvailableChain.GridCO.clock_row_admitted_origin
#print axioms AvailableChain.GridCO.clock_row_admitted_origin
#check AvailableChain.GridCO.clock_row_origin
#print axioms AvailableChain.GridCO.clock_row_origin
#check AvailableChain.GridCO.clock_stable_of_no_gate
#print axioms AvailableChain.GridCO.clock_stable_of_no_gate
#check AvailableChain.GridCO.clock_stored_prefix_closed
#print axioms AvailableChain.GridCO.clock_stored_prefix_closed
#check AvailableChain.GridCO.clock_target_origin
#print axioms AvailableChain.GridCO.clock_target_origin
#check AvailableChain.GridCO.clock_targetsStored
#print axioms AvailableChain.GridCO.clock_targetsStored
#check AvailableChain.GridCO.clock_unique_keys
#print axioms AvailableChain.GridCO.clock_unique_keys
#check AvailableChain.GridCO.clock_votes
#print axioms AvailableChain.GridCO.clock_votes
#check AvailableChain.GridCO.confirmationFrom_extends
#print axioms AvailableChain.GridCO.confirmationFrom_extends
#check AvailableChain.GridCO.confirmationFrom_mem
#print axioms AvailableChain.GridCO.confirmationFrom_mem
#check AvailableChain.GridCO.confirmation_covers_early_honest_batch
#print axioms AvailableChain.GridCO.confirmation_covers_early_honest_batch
#check AvailableChain.GridCO.confirmation_covers_majority
#print axioms AvailableChain.GridCO.confirmation_covers_majority
#check AvailableChain.GridCO.confirmation_eq_fresh_majority
#print axioms AvailableChain.GridCO.confirmation_eq_fresh_majority
#check AvailableChain.GridCO.confirmation_eq_from_genesis
#print axioms AvailableChain.GridCO.confirmation_eq_from_genesis
#check AvailableChain.GridCO.confirmation_eq_of_receiptData
#print axioms AvailableChain.GridCO.confirmation_eq_of_receiptData
#check AvailableChain.GridCO.confirmation_majority
#print axioms AvailableChain.GridCO.confirmation_majority
#check AvailableChain.GridCO.confirmation_mem
#print axioms AvailableChain.GridCO.confirmation_mem
#check AvailableChain.GridCO.confirmation_slot_le
#print axioms AvailableChain.GridCO.confirmation_slot_le
#check AvailableChain.GridCO.conflicting_support_sum_le_late
#print axioms AvailableChain.GridCO.conflicting_support_sum_le_late
#check AvailableChain.GridCO.coverage_from_engine
#print axioms AvailableChain.GridCO.coverage_from_engine
#check AvailableChain.GridCO.delivered_proposal_stored
#print axioms AvailableChain.GridCO.delivered_proposal_stored
#check AvailableChain.GridCO.delivery_now_ge_public
#print axioms AvailableChain.GridCO.delivery_now_ge_public
#check AvailableChain.GridCO.delivery_prefix_before_cut
#print axioms AvailableChain.GridCO.delivery_prefix_before_cut
#check AvailableChain.GridCO.deps_stable
#print axioms AvailableChain.GridCO.deps_stable
#check AvailableChain.GridCO.earlyVotes_subset_lateVotes
#print axioms AvailableChain.GridCO.earlyVotes_subset_lateVotes
#check AvailableChain.GridCO.early_handled_honest_head_stored
#print axioms AvailableChain.GridCO.early_handled_honest_head_stored
#check AvailableChain.GridCO.early_support_at_proposal
#print axioms AvailableChain.GridCO.early_support_at_proposal
#check AvailableChain.GridCO.emitted_head_action
#print axioms AvailableChain.GridCO.emitted_head_action
#check AvailableChain.GridCO.emitted_head_compatible_of_protection
#print axioms AvailableChain.GridCO.emitted_head_compatible_of_protection
#check AvailableChain.GridCO.emitted_head_target_stored
#print axioms AvailableChain.GridCO.emitted_head_target_stored
#check AvailableChain.GridCO.emitted_proposal_action
#print axioms AvailableChain.GridCO.emitted_proposal_action
#check AvailableChain.GridCO.equivocates_congr
#print axioms AvailableChain.GridCO.equivocates_congr
#check AvailableChain.GridCO.equivocates_eq_of_mem_or_equivocates
#print axioms AvailableChain.GridCO.equivocates_eq_of_mem_or_equivocates
#check AvailableChain.GridCO.equivocates_false_of_unique
#print axioms AvailableChain.GridCO.equivocates_false_of_unique
#check AvailableChain.GridCO.equivocates_mono
#print axioms AvailableChain.GridCO.equivocates_mono
#check AvailableChain.GridCO.equivocates_of_mem_or_equivocates
#print axioms AvailableChain.GridCO.equivocates_of_mem_or_equivocates
#check AvailableChain.GridCO.excludes_clock
#print axioms AvailableChain.GridCO.excludes_clock
#check AvailableChain.GridCO.excludes_head_iff
#print axioms AvailableChain.GridCO.excludes_head_iff
#check AvailableChain.GridCO.excludes_inert
#print axioms AvailableChain.GridCO.excludes_inert
#check AvailableChain.GridCO.excludes_not_processed
#print axioms AvailableChain.GridCO.excludes_not_processed
#check AvailableChain.GridCO.excludes_process
#print axioms AvailableChain.GridCO.excludes_process
#check AvailableChain.GridCO.excludes_proposal
#print axioms AvailableChain.GridCO.excludes_proposal
#check AvailableChain.GridCO.expire_comparable_targets
#print axioms AvailableChain.GridCO.expire_comparable_targets
#check AvailableChain.GridCO.expire_prefix_deadline_order
#print axioms AvailableChain.GridCO.expire_prefix_deadline_order
#check AvailableChain.GridCO.expire_protectsUntil
#print axioms AvailableChain.GridCO.expire_protectsUntil
#check AvailableChain.GridCO.fold_heads_mem_or_equivocates
#print axioms AvailableChain.GridCO.fold_heads_mem_or_equivocates
#check AvailableChain.GridCO.fold_new_head_label
#print axioms AvailableChain.GridCO.fold_new_head_label
#check AvailableChain.GridCO.fold_write_protectsUntil
#print axioms AvailableChain.GridCO.fold_write_protectsUntil
#check AvailableChain.GridCO.foldl_unique_keys
#print axioms AvailableChain.GridCO.foldl_unique_keys
#check AvailableChain.GridCO.forkChoice_adopts_of_proposal_transport
#print axioms AvailableChain.GridCO.forkChoice_adopts_of_proposal_transport
#check AvailableChain.GridCO.forkChoice_adopts_stored_proposal
#print axioms AvailableChain.GridCO.forkChoice_adopts_stored_proposal
#check AvailableChain.GridCO.forkChoice_covers_of_path_dominance
#print axioms AvailableChain.GridCO.forkChoice_covers_of_path_dominance
#check AvailableChain.GridCO.forkChoice_covers_of_transfer
#print axioms AvailableChain.GridCO.forkChoice_covers_of_transfer
#check AvailableChain.GridCO.forkChoice_extends_liveRoot
#print axioms AvailableChain.GridCO.forkChoice_extends_liveRoot
#check AvailableChain.GridCO.freezeInput_receiptPrefix_nextHead
#print axioms AvailableChain.GridCO.freezeInput_receiptPrefix_nextHead
#check AvailableChain.GridCO.freezeView_at_input
#print axioms AvailableChain.GridCO.freezeView_at_input
#check AvailableChain.GridCO.freezeView_eq_of_receiptData
#print axioms AvailableChain.GridCO.freezeView_eq_of_receiptData
#check AvailableChain.GridCO.frozenAt_after_freeze
#print axioms AvailableChain.GridCO.frozenAt_after_freeze
#check AvailableChain.GridCO.frozen_blocks_at_proposer
#print axioms AvailableChain.GridCO.frozen_blocks_at_proposer
#check AvailableChain.GridCO.frozen_raw_at_proposer
#print axioms AvailableChain.GridCO.frozen_raw_at_proposer
#check AvailableChain.GridCO.frozen_support_at_proposer
#print axioms AvailableChain.GridCO.frozen_support_at_proposer
#check AvailableChain.GridCO.gateFrom_blocks
#print axioms AvailableChain.GridCO.gateFrom_blocks
#check AvailableChain.GridCO.gateFrom_eq_writeKeys
#print axioms AvailableChain.GridCO.gateFrom_eq_writeKeys
#check AvailableChain.GridCO.gateFrom_target_origin
#print axioms AvailableChain.GridCO.gateFrom_target_origin
#check AvailableChain.GridCO.gateWriteKeys_closed
#print axioms AvailableChain.GridCO.gateWriteKeys_closed
#check AvailableChain.GridCO.gateWriteKeys_def
#print axioms AvailableChain.GridCO.gateWriteKeys_def
#check AvailableChain.GridCO.gate_blocks
#print axioms AvailableChain.GridCO.gate_blocks
#check AvailableChain.GridCO.gate_comparable_targets
#print axioms AvailableChain.GridCO.gate_comparable_targets
#check AvailableChain.GridCO.gate_covers_result
#print axioms AvailableChain.GridCO.gate_covers_result
#check AvailableChain.GridCO.gate_deadlines_aligned
#print axioms AvailableChain.GridCO.gate_deadlines_aligned
#check AvailableChain.GridCO.gate_deadlines_at_most
#print axioms AvailableChain.GridCO.gate_deadlines_at_most
#check AvailableChain.GridCO.gate_eq_from_genesis
#print axioms AvailableChain.GridCO.gate_eq_from_genesis
#check AvailableChain.GridCO.gate_eq_writeKeys
#print axioms AvailableChain.GridCO.gate_eq_writeKeys
#check AvailableChain.GridCO.gate_frozen
#print axioms AvailableChain.GridCO.gate_frozen
#check AvailableChain.GridCO.gate_genuine
#print axioms AvailableChain.GridCO.gate_genuine
#check AvailableChain.GridCO.gate_input_genuine_origin
#print axioms AvailableChain.GridCO.gate_input_genuine_origin
#check AvailableChain.GridCO.gate_input_record
#print axioms AvailableChain.GridCO.gate_input_record
#check AvailableChain.GridCO.gate_input_slot_lt
#print axioms AvailableChain.GridCO.gate_input_slot_lt
#check AvailableChain.GridCO.gate_live_rows
#print axioms AvailableChain.GridCO.gate_live_rows
#check AvailableChain.GridCO.gate_now
#print axioms AvailableChain.GridCO.gate_now
#check AvailableChain.GridCO.gate_prefix_deadline_order
#print axioms AvailableChain.GridCO.gate_prefix_deadline_order
#check AvailableChain.GridCO.gate_preserves_protected_prefix
#print axioms AvailableChain.GridCO.gate_preserves_protected_prefix
#check AvailableChain.GridCO.gate_protectsUntil
#print axioms AvailableChain.GridCO.gate_protectsUntil
#check AvailableChain.GridCO.gate_receiptData
#print axioms AvailableChain.GridCO.gate_receiptData
#check AvailableChain.GridCO.gate_record_genuine_origin
#print axioms AvailableChain.GridCO.gate_record_genuine_origin
#check AvailableChain.GridCO.gate_record_origin_after_repair
#print axioms AvailableChain.GridCO.gate_record_origin_after_repair
#check AvailableChain.GridCO.gate_repairs_fresh_slot
#print axioms AvailableChain.GridCO.gate_repairs_fresh_slot
#check AvailableChain.GridCO.gate_repairs_record
#print axioms AvailableChain.GridCO.gate_repairs_record
#check AvailableChain.GridCO.gate_row_admitted_origin
#print axioms AvailableChain.GridCO.gate_row_admitted_origin
#check AvailableChain.GridCO.gate_row_origin
#print axioms AvailableChain.GridCO.gate_row_origin
#check AvailableChain.GridCO.gate_stable_cases
#print axioms AvailableChain.GridCO.gate_stable_cases
#check AvailableChain.GridCO.gate_target_origin
#print axioms AvailableChain.GridCO.gate_target_origin
#check AvailableChain.GridCO.gate_unique_keys
#print axioms AvailableChain.GridCO.gate_unique_keys
#check AvailableChain.GridCO.gate_veto
#print axioms AvailableChain.GridCO.gate_veto
#check AvailableChain.GridCO.gate_veto_of_live_target
#print axioms AvailableChain.GridCO.gate_veto_of_live_target
#check AvailableChain.GridCO.gate_votes
#print axioms AvailableChain.GridCO.gate_votes
#check AvailableChain.GridCO.genesis_stored_at_time
#print axioms AvailableChain.GridCO.genesis_stored_at_time
#check AvailableChain.GridCO.genuine_prefix_at_ordinary_proposal
#print axioms AvailableChain.GridCO.genuine_prefix_at_ordinary_proposal
#check AvailableChain.GridCO.ghost_adopts_of_eligible_proposal_transport
#print axioms AvailableChain.GridCO.ghost_adopts_of_eligible_proposal_transport
#check AvailableChain.GridCO.ghost_adopts_of_rooted_proposal_transport
#print axioms AvailableChain.GridCO.ghost_adopts_of_rooted_proposal_transport
#check AvailableChain.GridCO.goldfishScore_block_eq
#print axioms AvailableChain.GridCO.goldfishScore_block_eq
#check AvailableChain.GridCO.goldfishScore_congr
#print axioms AvailableChain.GridCO.goldfishScore_congr
#check AvailableChain.GridCO.goldfishScore_eq_card
#print axioms AvailableChain.GridCO.goldfishScore_eq_card
#check AvailableChain.GridCO.goldfishScore_eq_of_mem_or_equivocates
#print axioms AvailableChain.GridCO.goldfishScore_eq_of_mem_or_equivocates
#check AvailableChain.GridCO.goldfishScore_mono
#print axioms AvailableChain.GridCO.goldfishScore_mono
#check AvailableChain.GridCO.goldfishScore_prefix_mono
#print axioms AvailableChain.GridCO.goldfishScore_prefix_mono
#check AvailableChain.GridCO.gridCO_excludes
#print axioms AvailableChain.GridCO.gridCO_excludes
#check AvailableChain.GridCO.grid_sources_and_rows_from_engine
#print axioms AvailableChain.GridCO.grid_sources_and_rows_from_engine
#check AvailableChain.GridCO.handled_before_proposal_of_ready
#print axioms AvailableChain.GridCO.handled_before_proposal_of_ready
#check AvailableChain.GridCO.handled_head_mem_of_not_equivocating
#print axioms AvailableChain.GridCO.handled_head_mem_of_not_equivocating
#check AvailableChain.GridCO.handled_head_mem_or_equivocates
#print axioms AvailableChain.GridCO.handled_head_mem_or_equivocates
#check AvailableChain.GridCO.handled_head_stamped_or_equivocates
#print axioms AvailableChain.GridCO.handled_head_stamped_or_equivocates
#check AvailableChain.GridCO.handled_honest_head_stored
#print axioms AvailableChain.GridCO.handled_honest_head_stored
#check AvailableChain.GridCO.handled_proposal_stored
#print axioms AvailableChain.GridCO.handled_proposal_stored
#check AvailableChain.GridCO.handles_carries
#print axioms AvailableChain.GridCO.handles_carries
#check AvailableChain.GridCO.handles_proposal_direct
#print axioms AvailableChain.GridCO.handles_proposal_direct
#check AvailableChain.GridCO.head_delivery_current_label
#print axioms AvailableChain.GridCO.head_delivery_current_label
#check AvailableChain.GridCO.head_excluded_before_equivocates
#print axioms AvailableChain.GridCO.head_excluded_before_equivocates
#check AvailableChain.GridCO.head_not_excluded_before
#print axioms AvailableChain.GridCO.head_not_excluded_before
#check AvailableChain.GridCO.head_not_excluded_or_equivocates
#print axioms AvailableChain.GridCO.head_not_excluded_or_equivocates
#check AvailableChain.GridCO.head_walk_mem_blocks
#print axioms AvailableChain.GridCO.head_walk_mem_blocks
#check AvailableChain.GridCO.head_wire_shape
#print axioms AvailableChain.GridCO.head_wire_shape
#check AvailableChain.GridCO.honest_early_mem_cleanSupport
#print axioms AvailableChain.GridCO.honest_early_mem_cleanSupport
#check AvailableChain.GridCO.honest_head_not_excluded_before
#print axioms AvailableChain.GridCO.honest_head_not_excluded_before
#check AvailableChain.GridCO.honest_not_equivocating_at_event
#print axioms AvailableChain.GridCO.honest_not_equivocating_at_event
#check AvailableChain.GridCO.honest_proposal_contains_source_root
#print axioms AvailableChain.GridCO.honest_proposal_contains_source_root
#check AvailableChain.GridCO.honest_proposal_exists
#print axioms AvailableChain.GridCO.honest_proposal_exists
#check AvailableChain.GridCO.honest_proposal_heads_of_ordinary_parent
#print axioms AvailableChain.GridCO.honest_proposal_heads_of_ordinary_parent
#check AvailableChain.GridCO.honest_proposal_parent_stored
#print axioms AvailableChain.GridCO.honest_proposal_parent_stored
#check AvailableChain.GridCO.honest_proposal_payload_unique
#print axioms AvailableChain.GridCO.honest_proposal_payload_unique
#check AvailableChain.GridCO.honest_proposal_raw_extension
#print axioms AvailableChain.GridCO.honest_proposal_raw_extension
#check AvailableChain.GridCO.honest_proposal_score_extension
#print axioms AvailableChain.GridCO.honest_proposal_score_extension
#check AvailableChain.GridCO.honest_proposal_stored_at_head
#print axioms AvailableChain.GridCO.honest_proposal_stored_at_head
#check AvailableChain.GridCO.honest_proposal_support_extension
#print axioms AvailableChain.GridCO.honest_proposal_support_extension
#check AvailableChain.GridCO.honest_proposal_tree_reflects
#print axioms AvailableChain.GridCO.honest_proposal_tree_reflects
#check AvailableChain.GridCO.honest_proposal_views
#print axioms AvailableChain.GridCO.honest_proposal_views
#check AvailableChain.GridCO.included_from_engine
#print axioms AvailableChain.GridCO.included_from_engine
#check AvailableChain.GridCO.initial_comparable_targets
#print axioms AvailableChain.GridCO.initial_comparable_targets
#check AvailableChain.GridCO.initial_deadline_horizon
#print axioms AvailableChain.GridCO.initial_deadline_horizon
#check AvailableChain.GridCO.initial_deadlines_aligned
#print axioms AvailableChain.GridCO.initial_deadlines_aligned
#check AvailableChain.GridCO.initial_live_rows
#print axioms AvailableChain.GridCO.initial_live_rows
#check AvailableChain.GridCO.initial_map_reachable
#print axioms AvailableChain.GridCO.initial_map_reachable
#check AvailableChain.GridCO.initial_prefix_deadline_order
#print axioms AvailableChain.GridCO.initial_prefix_deadline_order
#check AvailableChain.GridCO.initial_stamped
#print axioms AvailableChain.GridCO.initial_stamped
#check AvailableChain.GridCO.initial_stored_prefix_closed
#print axioms AvailableChain.GridCO.initial_stored_prefix_closed
#check AvailableChain.GridCO.initial_unique_keys
#print axioms AvailableChain.GridCO.initial_unique_keys
#check AvailableChain.GridCO.lateSeats_card
#print axioms AvailableChain.GridCO.lateSeats_card
#check AvailableChain.GridCO.late_voterCount_le_awake_add_faulty
#print axioms AvailableChain.GridCO.late_voterCount_le_awake_add_faulty
#check AvailableChain.GridCO.liveRoot_below_of_rows
#print axioms AvailableChain.GridCO.liveRoot_below_of_rows
#check AvailableChain.GridCO.liveRoot_eq_fold
#print axioms AvailableChain.GridCO.liveRoot_eq_fold
#check AvailableChain.GridCO.liveRoot_is_deepest
#print axioms AvailableChain.GridCO.liveRoot_is_deepest
#check AvailableChain.GridCO.liveRoot_mem_blocks
#print axioms AvailableChain.GridCO.liveRoot_mem_blocks
#check AvailableChain.GridCO.liveTarget_preceq_liveRoot
#print axioms AvailableChain.GridCO.liveTarget_preceq_liveRoot
#check AvailableChain.GridCO.local_early_at_freeze
#print axioms AvailableChain.GridCO.local_early_at_freeze
#check AvailableChain.GridCO.local_transferReceipts
#print axioms AvailableChain.GridCO.local_transferReceipts
#check AvailableChain.GridCO.local_transfer_from_engine
#print axioms AvailableChain.GridCO.local_transfer_from_engine
#check AvailableChain.GridCO.majority_support_dominates_conflict
#print axioms AvailableChain.GridCO.majority_support_dominates_conflict
#check AvailableChain.GridCO.nextHeadState_carried_raw_receipt
#print axioms AvailableChain.GridCO.nextHeadState_carried_raw_receipt
#check AvailableChain.GridCO.nextHeadState_conflict_stronger
#print axioms AvailableChain.GridCO.nextHeadState_conflict_stronger
#check AvailableChain.GridCO.nextHeadState_frozenAt
#print axioms AvailableChain.GridCO.nextHeadState_frozenAt
#check AvailableChain.GridCO.nextHeadState_frozenAt_of_execution
#print axioms AvailableChain.GridCO.nextHeadState_frozenAt_of_execution
#check AvailableChain.GridCO.nextHeadState_frozenAt_of_schedule
#print axioms AvailableChain.GridCO.nextHeadState_frozenAt_of_schedule
#check AvailableChain.GridCO.nextHeadState_honest_proposal_unique
#print axioms AvailableChain.GridCO.nextHeadState_honest_proposal_unique
#check AvailableChain.GridCO.nextHeadState_proposal_wellFormed
#print axioms AvailableChain.GridCO.nextHeadState_proposal_wellFormed
#check AvailableChain.GridCO.nextHeadState_raw_receipt
#print axioms AvailableChain.GridCO.nextHeadState_raw_receipt
#check AvailableChain.GridCO.nextHeadState_raw_receipt_of_execution
#print axioms AvailableChain.GridCO.nextHeadState_raw_receipt_of_execution
#check AvailableChain.GridCO.nextHeadState_row_origin_since
#print axioms AvailableChain.GridCO.nextHeadState_row_origin_since
#check AvailableChain.GridCO.nextHeadState_row_source_after_stage
#print axioms AvailableChain.GridCO.nextHeadState_row_source_after_stage
#check AvailableChain.GridCO.nextHeadState_row_survives_release
#print axioms AvailableChain.GridCO.nextHeadState_row_survives_release
#check AvailableChain.GridCO.nextHeadState_support_subset_raw
#print axioms AvailableChain.GridCO.nextHeadState_support_subset_raw
#check AvailableChain.GridCO.nextHeadState_support_subset_raw_of_execution
#print axioms AvailableChain.GridCO.nextHeadState_support_subset_raw_of_execution
#check AvailableChain.GridCO.nextHeadState_target_genuine_origin
#print axioms AvailableChain.GridCO.nextHeadState_target_genuine_origin
#check AvailableChain.GridCO.nextHeadState_targets_compatible
#print axioms AvailableChain.GridCO.nextHeadState_targets_compatible
#check AvailableChain.GridCO.next_head_emitted
#print axioms AvailableChain.GridCO.next_head_emitted
#check AvailableChain.GridCO.non_equivocating_unique
#print axioms AvailableChain.GridCO.non_equivocating_unique
#check AvailableChain.GridCO.outage_covering_protection
#print axioms AvailableChain.GridCO.outage_covering_protection
#check AvailableChain.GridCO.pending_coverage
#print axioms AvailableChain.GridCO.pending_coverage
#check AvailableChain.GridCO.pending_gate_guard
#print axioms AvailableChain.GridCO.pending_gate_guard
#check AvailableChain.GridCO.pending_genuine_extends_history
#print axioms AvailableChain.GridCO.pending_genuine_extends_history
#check AvailableChain.GridCO.pending_outage_protection
#print axioms AvailableChain.GridCO.pending_outage_protection
#check AvailableChain.GridCO.permanent_support_at_level
#print axioms AvailableChain.GridCO.permanent_support_at_level
#check AvailableChain.GridCO.permanent_support_of_release
#print axioms AvailableChain.GridCO.permanent_support_of_release
#check AvailableChain.GridCO.prefixSupportSeats_disjoint
#print axioms AvailableChain.GridCO.prefixSupportSeats_disjoint
#check AvailableChain.GridCO.prefixSupportSeats_subset_late
#print axioms AvailableChain.GridCO.prefixSupportSeats_subset_late
#check AvailableChain.GridCO.prefixSupportSeats_witness
#print axioms AvailableChain.GridCO.prefixSupportSeats_witness
#check AvailableChain.GridCO.prefixSupport_block_eq
#print axioms AvailableChain.GridCO.prefixSupport_block_eq
#check AvailableChain.GridCO.prefixSupport_eq_card
#print axioms AvailableChain.GridCO.prefixSupport_eq_card
#check AvailableChain.GridCO.prefixSupport_eq_of_receiptData
#print axioms AvailableChain.GridCO.prefixSupport_eq_of_receiptData
#check AvailableChain.GridCO.prefixSupport_ge_early_honest_batch
#print axioms AvailableChain.GridCO.prefixSupport_ge_early_honest_batch
#check AvailableChain.GridCO.prefixSupport_mono
#print axioms AvailableChain.GridCO.prefixSupport_mono
#check AvailableChain.GridCO.prefixSupport_target
#print axioms AvailableChain.GridCO.prefixSupport_target
#check AvailableChain.GridCO.preserve_from_engine
#print axioms AvailableChain.GridCO.preserve_from_engine
#check AvailableChain.GridCO.preserve_of_early_delivery
#print axioms AvailableChain.GridCO.preserve_of_early_delivery
#check AvailableChain.GridCO.process_block_stamp_origin
#print axioms AvailableChain.GridCO.process_block_stamp_origin
#check AvailableChain.GridCO.process_blocks_subset
#print axioms AvailableChain.GridCO.process_blocks_subset
#check AvailableChain.GridCO.process_deadline_horizon
#print axioms AvailableChain.GridCO.process_deadline_horizon
#check AvailableChain.GridCO.process_deadlines_aligned
#print axioms AvailableChain.GridCO.process_deadlines_aligned
#check AvailableChain.GridCO.process_frozen
#print axioms AvailableChain.GridCO.process_frozen
#check AvailableChain.GridCO.process_genuine
#print axioms AvailableChain.GridCO.process_genuine
#check AvailableChain.GridCO.process_live_rows
#print axioms AvailableChain.GridCO.process_live_rows
#check AvailableChain.GridCO.process_map_reachable
#print axioms AvailableChain.GridCO.process_map_reachable
#check AvailableChain.GridCO.process_new_block
#print axioms AvailableChain.GridCO.process_new_block
#check AvailableChain.GridCO.process_new_block_slot
#print axioms AvailableChain.GridCO.process_new_block_slot
#check AvailableChain.GridCO.process_new_head_label
#print axioms AvailableChain.GridCO.process_new_head_label
#check AvailableChain.GridCO.process_now
#print axioms AvailableChain.GridCO.process_now
#check AvailableChain.GridCO.process_obligations
#print axioms AvailableChain.GridCO.process_obligations
#check AvailableChain.GridCO.process_proposal_origin
#print axioms AvailableChain.GridCO.process_proposal_origin
#check AvailableChain.GridCO.process_proposals_subset
#print axioms AvailableChain.GridCO.process_proposals_subset
#check AvailableChain.GridCO.process_protectsUntil
#print axioms AvailableChain.GridCO.process_protectsUntil
#check AvailableChain.GridCO.process_receiptPrefix
#print axioms AvailableChain.GridCO.process_receiptPrefix
#check AvailableChain.GridCO.process_recordSlotOrdered
#print axioms AvailableChain.GridCO.process_recordSlotOrdered
#check AvailableChain.GridCO.process_stable
#print axioms AvailableChain.GridCO.process_stable
#check AvailableChain.GridCO.process_stored_prefix_closed
#print axioms AvailableChain.GridCO.process_stored_prefix_closed
#check AvailableChain.GridCO.process_vote_origin
#print axioms AvailableChain.GridCO.process_vote_origin
#check AvailableChain.GridCO.process_vote_stamp_origin
#print axioms AvailableChain.GridCO.process_vote_stamp_origin
#check AvailableChain.GridCO.process_votes_subset
#print axioms AvailableChain.GridCO.process_votes_subset
#check AvailableChain.GridCO.processed_stable
#print axioms AvailableChain.GridCO.processed_stable
#check AvailableChain.GridCO.proposalState_receiptData
#print axioms AvailableChain.GridCO.proposalState_receiptData
#check AvailableChain.GridCO.proposalState_rootInjectiveBelow
#print axioms AvailableChain.GridCO.proposalState_rootInjectiveBelow
#check AvailableChain.GridCO.proposalState_target_genuine_origin
#print axioms AvailableChain.GridCO.proposalState_target_genuine_origin
#check AvailableChain.GridCO.proposalTransferReceipts_from_engine
#print axioms AvailableChain.GridCO.proposalTransferReceipts_from_engine
#check AvailableChain.GridCO.proposalViewTransport_from_engine
#print axioms AvailableChain.GridCO.proposalViewTransport_from_engine
#check AvailableChain.GridCO.proposal_blocks_at_head
#print axioms AvailableChain.GridCO.proposal_blocks_at_head
#check AvailableChain.GridCO.proposal_delivery_current_label
#print axioms AvailableChain.GridCO.proposal_delivery_current_label
#check AvailableChain.GridCO.proposal_not_excluded
#print axioms AvailableChain.GridCO.proposal_not_excluded
#check AvailableChain.GridCO.proposal_parent_ordinary_of_root
#print axioms AvailableChain.GridCO.proposal_parent_ordinary_of_root
#check AvailableChain.GridCO.proposal_path_mem_voterTree
#print axioms AvailableChain.GridCO.proposal_path_mem_voterTree
#check AvailableChain.GridCO.proposal_prefix_mem_voterTree
#print axioms AvailableChain.GridCO.proposal_prefix_mem_voterTree
#check AvailableChain.GridCO.proposal_raw_in_previous_late
#print axioms AvailableChain.GridCO.proposal_raw_in_previous_late
#check AvailableChain.GridCO.proposal_raw_mem_voterView
#print axioms AvailableChain.GridCO.proposal_raw_mem_voterView
#check AvailableChain.GridCO.proposal_support_mem_voterSupportView
#print axioms AvailableChain.GridCO.proposal_support_mem_voterSupportView
#check AvailableChain.GridCO.protection_from_armed_index
#print axioms AvailableChain.GridCO.protection_from_armed_index
#check AvailableChain.GridCO.protection_from_armed_read
#print axioms AvailableChain.GridCO.protection_from_armed_read
#check AvailableChain.GridCO.read_field_eq_clock
#print axioms AvailableChain.GridCO.read_field_eq_clock
#check AvailableChain.GridCO.read_gate_covers_result
#print axioms AvailableChain.GridCO.read_gate_covers_result
#check AvailableChain.GridCO.read_gate_record_cases
#print axioms AvailableChain.GridCO.read_gate_record_cases
#check AvailableChain.GridCO.read_gate_repairs_early_honest_batch
#print axioms AvailableChain.GridCO.read_gate_repairs_early_honest_batch
#check AvailableChain.GridCO.read_gate_repairs_fresh_slot
#print axioms AvailableChain.GridCO.read_gate_repairs_fresh_slot
#check AvailableChain.GridCO.read_gate_repairs_heads
#print axioms AvailableChain.GridCO.read_gate_repairs_heads
#check AvailableChain.GridCO.read_gate_repairs_honest_support
#print axioms AvailableChain.GridCO.read_gate_repairs_honest_support
#check AvailableChain.GridCO.read_gate_repairs_majority
#print axioms AvailableChain.GridCO.read_gate_repairs_majority
#check AvailableChain.GridCO.read_gate_writes_admitted_prefix
#print axioms AvailableChain.GridCO.read_gate_writes_admitted_prefix
#check AvailableChain.GridCO.read_gate_writes_supported_prefix
#print axioms AvailableChain.GridCO.read_gate_writes_supported_prefix
#check AvailableChain.GridCO.read_obligations_eq_clock
#print axioms AvailableChain.GridCO.read_obligations_eq_clock
#check AvailableChain.GridCO.read_stable_before_first_gate
#print axioms AvailableChain.GridCO.read_stable_before_first_gate
#check AvailableChain.GridCO.read_stable_eq_clock
#print axioms AvailableChain.GridCO.read_stable_eq_clock
#check AvailableChain.GridCO.read_stable_eq_latest_gate
#print axioms AvailableChain.GridCO.read_stable_eq_latest_gate
#check AvailableChain.GridCO.read_stable_eq_of_no_gate
#print axioms AvailableChain.GridCO.read_stable_eq_of_no_gate
#check AvailableChain.GridCO.read_stable_slot_le
#print axioms AvailableChain.GridCO.read_stable_slot_le
#check AvailableChain.GridCO.receiptPrefix_of_data_eq
#print axioms AvailableChain.GridCO.receiptPrefix_of_data_eq
#check AvailableChain.GridCO.receipt_current_window
#print axioms AvailableChain.GridCO.receipt_current_window
#check AvailableChain.GridCO.recordGenuine_origin
#print axioms AvailableChain.GridCO.recordGenuine_origin
#check AvailableChain.GridCO.recordGenuine_subset
#print axioms AvailableChain.GridCO.recordGenuine_subset
#check AvailableChain.GridCO.recovered_of_source_boundary
#print axioms AvailableChain.GridCO.recovered_of_source_boundary
#check AvailableChain.GridCO.recovery_proposal_after_sources
#print axioms AvailableChain.GridCO.recovery_proposal_after_sources
#check AvailableChain.GridCO.recovery_proposal_after_stages
#print axioms AvailableChain.GridCO.recovery_proposal_after_stages
#check AvailableChain.GridCO.recovery_source_stage
#print axioms AvailableChain.GridCO.recovery_source_stage
#check AvailableChain.GridCO.recovery_stage
#print axioms AvailableChain.GridCO.recovery_stage
#check AvailableChain.GridCO.releaseConflictSeats_mono
#print axioms AvailableChain.GridCO.releaseConflictSeats_mono
#check AvailableChain.GridCO.releaseCount_eq_card
#print axioms AvailableChain.GridCO.releaseCount_eq_card
#check AvailableChain.GridCO.releaseCount_eq_of_receiptData
#print axioms AvailableChain.GridCO.releaseCount_eq_of_receiptData
#check AvailableChain.GridCO.releaseCount_le_faults_of_emissions
#print axioms AvailableChain.GridCO.releaseCount_le_faults_of_emissions
#check AvailableChain.GridCO.releaseCount_mono
#print axioms AvailableChain.GridCO.releaseCount_mono
#check AvailableChain.GridCO.release_clears_conflict_from_engine
#print axioms AvailableChain.GridCO.release_clears_conflict_from_engine
#check AvailableChain.GridCO.release_comparable_targets
#print axioms AvailableChain.GridCO.release_comparable_targets
#check AvailableChain.GridCO.release_prefix_deadline_order
#print axioms AvailableChain.GridCO.release_prefix_deadline_order
#check AvailableChain.GridCO.release_protectsUntil
#print axioms AvailableChain.GridCO.release_protectsUntil
#check AvailableChain.GridCO.release_subset
#print axioms AvailableChain.GridCO.release_subset
#check AvailableChain.GridCO.repaired_gate_record_prefix
#print axioms AvailableChain.GridCO.repaired_gate_record_prefix
#check AvailableChain.GridCO.repaired_gate_records_compatible
#print axioms AvailableChain.GridCO.repaired_gate_records_compatible
#check AvailableChain.GridCO.resilient_of_covering_protection
#print axioms AvailableChain.GridCO.resilient_of_covering_protection
#check AvailableChain.GridCO.resolvedBefore_block
#print axioms AvailableChain.GridCO.resolvedBefore_block
#check AvailableChain.GridCO.resolvedBefore_eq_of_receiptData
#print axioms AvailableChain.GridCO.resolvedBefore_eq_of_receiptData
#check AvailableChain.GridCO.run_genuine_mono
#print axioms AvailableChain.GridCO.run_genuine_mono
#check AvailableChain.GridCO.run_genuine_origin
#print axioms AvailableChain.GridCO.run_genuine_origin
#check AvailableChain.GridCO.run_map_reachable
#print axioms AvailableChain.GridCO.run_map_reachable
#check AvailableChain.GridCO.run_row_genuine_admitted_origin
#print axioms AvailableChain.GridCO.run_row_genuine_admitted_origin
#check AvailableChain.GridCO.run_row_genuine_origin
#print axioms AvailableChain.GridCO.run_row_genuine_origin
#check AvailableChain.GridCO.run_row_origin_since
#print axioms AvailableChain.GridCO.run_row_origin_since
#check AvailableChain.GridCO.run_stampsBounded
#print axioms AvailableChain.GridCO.run_stampsBounded
#check AvailableChain.GridCO.run_target_genuine_origin
#print axioms AvailableChain.GridCO.run_target_genuine_origin
#check AvailableChain.GridCO.run_targetsStored
#print axioms AvailableChain.GridCO.run_targetsStored
#check AvailableChain.GridCO.run_time_map_reachable
#print axioms AvailableChain.GridCO.run_time_map_reachable
#check AvailableChain.GridCO.run_time_recordSlotOrdered
#print axioms AvailableChain.GridCO.run_time_recordSlotOrdered
#check AvailableChain.GridCO.run_vote_stamps_stored
#print axioms AvailableChain.GridCO.run_vote_stamps_stored
#check AvailableChain.GridCO.safe_from_repaired_gate
#print axioms AvailableChain.GridCO.safe_from_repaired_gate
#check AvailableChain.GridCO.sameLabelSeatAlignment_from_engine
#print axioms AvailableChain.GridCO.sameLabelSeatAlignment_from_engine
#check AvailableChain.GridCO.sameLabel_from_engine
#print axioms AvailableChain.GridCO.sameLabel_from_engine
#check AvailableChain.GridCO.same_label_compatible_in_run
#print axioms AvailableChain.GridCO.same_label_compatible_in_run
#check AvailableChain.GridCO.same_label_compatible_of_window_bounds
#print axioms AvailableChain.GridCO.same_label_compatible_of_window_bounds
#check AvailableChain.GridCO.same_label_from_alignment
#print axioms AvailableChain.GridCO.same_label_from_alignment
#check AvailableChain.GridCO.same_label_of_seat_alignment
#print axioms AvailableChain.GridCO.same_label_of_seat_alignment
#check AvailableChain.GridCO.savedGenuine_input_origin
#print axioms AvailableChain.GridCO.savedGenuine_input_origin
#check AvailableChain.GridCO.seats_eq_of_mem_or_equivocates
#print axioms AvailableChain.GridCO.seats_eq_of_mem_or_equivocates
#check AvailableChain.GridCO.slowEligible_mono
#print axioms AvailableChain.GridCO.slowEligible_mono
#check AvailableChain.GridCO.snapshotSeatAlignment_from_engine
#print axioms AvailableChain.GridCO.snapshotSeatAlignment_from_engine
#check AvailableChain.GridCO.snapshot_count_of_relayed_seats
#print axioms AvailableChain.GridCO.snapshot_count_of_relayed_seats
#check AvailableChain.GridCO.snapshot_from_alignment
#print axioms AvailableChain.GridCO.snapshot_from_alignment
#check AvailableChain.GridCO.snapshot_from_engine
#print axioms AvailableChain.GridCO.snapshot_from_engine
#check AvailableChain.GridCO.snapshot_of_receipts
#print axioms AvailableChain.GridCO.snapshot_of_receipts
#check AvailableChain.GridCO.stable_monotone_from_engine
#print axioms AvailableChain.GridCO.stable_monotone_from_engine
#check AvailableChain.GridCO.stable_resilient_from_engine
#print axioms AvailableChain.GridCO.stable_resilient_from_engine
#check AvailableChain.GridCO.stable_safe_from_engine
#print axioms AvailableChain.GridCO.stable_safe_from_engine
#check AvailableChain.GridCO.stage_clock_row_support
#print axioms AvailableChain.GridCO.stage_clock_row_support
#check AvailableChain.GridCO.stage_gate_guard
#print axioms AvailableChain.GridCO.stage_gate_guard
#check AvailableChain.GridCO.stage_genuine_prefix
#print axioms AvailableChain.GridCO.stage_genuine_prefix
#check AvailableChain.GridCO.stage_honest_proposal_repair
#print axioms AvailableChain.GridCO.stage_honest_proposal_repair
#check AvailableChain.GridCO.stage_roots_at_ordinary_proposal
#print axioms AvailableChain.GridCO.stage_roots_at_ordinary_proposal
#check AvailableChain.GridCO.stampBlock_mem_of_stored
#print axioms AvailableChain.GridCO.stampBlock_mem_of_stored
#check AvailableChain.GridCO.stampVote_mem_of_stored
#print axioms AvailableChain.GridCO.stampVote_mem_of_stored
#check AvailableChain.GridCO.stamped_of_data_eq
#print axioms AvailableChain.GridCO.stamped_of_data_eq
#check AvailableChain.GridCO.stateAfter_now_le_event
#print axioms AvailableChain.GridCO.stateAfter_now_le_event
#check AvailableChain.GridCO.stateBefore_frozen_prefix
#print axioms AvailableChain.GridCO.stateBefore_frozen_prefix
#check AvailableChain.GridCO.stateBefore_now_le_event
#print axioms AvailableChain.GridCO.stateBefore_now_le_event
#check AvailableChain.GridCO.stateBefore_now_mono
#print axioms AvailableChain.GridCO.stateBefore_now_mono
#check AvailableChain.GridCO.stateBefore_now_source
#print axioms AvailableChain.GridCO.stateBefore_now_source
#check AvailableChain.GridCO.stateBefore_proposals_subset
#print axioms AvailableChain.GridCO.stateBefore_proposals_subset
#check AvailableChain.GridCO.stateBefore_receiptPrefix
#print axioms AvailableChain.GridCO.stateBefore_receiptPrefix
#check AvailableChain.GridCO.stateBefore_rootInjectiveBelow
#print axioms AvailableChain.GridCO.stateBefore_rootInjectiveBelow
#check AvailableChain.GridCO.stored_ancestors_root_injective
#print axioms AvailableChain.GridCO.stored_ancestors_root_injective
#check AvailableChain.GridCO.stored_before_head_slot_le
#print axioms AvailableChain.GridCO.stored_before_head_slot_le
#check AvailableChain.GridCO.stored_block_accepted
#print axioms AvailableChain.GridCO.stored_block_accepted
#check AvailableChain.GridCO.stored_block_accepted_before
#print axioms AvailableChain.GridCO.stored_block_accepted_before
#check AvailableChain.GridCO.stored_block_before_ready_proposal
#print axioms AvailableChain.GridCO.stored_block_before_ready_proposal
#check AvailableChain.GridCO.stored_block_in_run
#print axioms AvailableChain.GridCO.stored_block_in_run
#check AvailableChain.GridCO.stored_block_stamp_before_cut
#print axioms AvailableChain.GridCO.stored_block_stamp_before_cut
#check AvailableChain.GridCO.stored_block_stamp_source
#print axioms AvailableChain.GridCO.stored_block_stamp_source
#check AvailableChain.GridCO.stored_freeze_origin
#print axioms AvailableChain.GridCO.stored_freeze_origin
#check AvailableChain.GridCO.stored_head_accepted_before
#print axioms AvailableChain.GridCO.stored_head_accepted_before
#check AvailableChain.GridCO.stored_head_before_ready_proposal
#print axioms AvailableChain.GridCO.stored_head_before_ready_proposal
#check AvailableChain.GridCO.stored_head_stamp_before_cut
#print axioms AvailableChain.GridCO.stored_head_stamp_before_cut
#check AvailableChain.GridCO.stored_head_stamp_source
#print axioms AvailableChain.GridCO.stored_head_stamp_source
#check AvailableChain.GridCO.stored_honest_heads_equal
#print axioms AvailableChain.GridCO.stored_honest_heads_equal
#check AvailableChain.GridCO.stored_honest_heads_equal_at_event
#print axioms AvailableChain.GridCO.stored_honest_heads_equal_at_event
#check AvailableChain.GridCO.stored_honest_proposal_unique
#print axioms AvailableChain.GridCO.stored_honest_proposal_unique
#check AvailableChain.GridCO.stored_honest_seat_awake
#print axioms AvailableChain.GridCO.stored_honest_seat_awake
#check AvailableChain.GridCO.stored_honest_vote_emitted
#print axioms AvailableChain.GridCO.stored_honest_vote_emitted
#check AvailableChain.GridCO.stored_honest_vote_emitted_at_event
#print axioms AvailableChain.GridCO.stored_honest_vote_emitted_at_event
#check AvailableChain.GridCO.stored_proposal_admission
#print axioms AvailableChain.GridCO.stored_proposal_admission
#check AvailableChain.GridCO.stored_proposal_wellFormed
#print axioms AvailableChain.GridCO.stored_proposal_wellFormed
#check AvailableChain.GridCO.stored_vote_origin
#print axioms AvailableChain.GridCO.stored_vote_origin
#check AvailableChain.GridCO.stored_vote_stamp_before_cut
#print axioms AvailableChain.GridCO.stored_vote_stamp_before_cut
#check AvailableChain.GridCO.supported_stronger_rows_compatible
#print axioms AvailableChain.GridCO.supported_stronger_rows_compatible
#check AvailableChain.GridCO.surviving_conflict_stronger_from_engine
#print axioms AvailableChain.GridCO.surviving_conflict_stronger_from_engine
#check AvailableChain.GridCO.synchronous_accepted_block_before
#print axioms AvailableChain.GridCO.synchronous_accepted_block_before
#check AvailableChain.GridCO.synchronous_accepted_head_before
#print axioms AvailableChain.GridCO.synchronous_accepted_head_before
#check AvailableChain.GridCO.synchronous_block_path_at_gate
#print axioms AvailableChain.GridCO.synchronous_block_path_at_gate
#check AvailableChain.GridCO.synchronous_early_head_at_freeze
#print axioms AvailableChain.GridCO.synchronous_early_head_at_freeze
#check AvailableChain.GridCO.synchronous_early_head_at_release
#print axioms AvailableChain.GridCO.synchronous_early_head_at_release
#check AvailableChain.GridCO.synchronous_early_head_in_voterSupport
#print axioms AvailableChain.GridCO.synchronous_early_head_in_voterSupport
#check AvailableChain.GridCO.synchronous_early_path_in_voterTree
#print axioms AvailableChain.GridCO.synchronous_early_path_in_voterTree
#check AvailableChain.GridCO.synchronous_early_resolved_at_release
#print axioms AvailableChain.GridCO.synchronous_early_resolved_at_release
#check AvailableChain.GridCO.synchronous_early_target_at_freeze
#print axioms AvailableChain.GridCO.synchronous_early_target_at_freeze
#check AvailableChain.GridCO.synchronous_early_target_at_release
#print axioms AvailableChain.GridCO.synchronous_early_target_at_release
#check AvailableChain.GridCO.synchronous_early_vote_late
#print axioms AvailableChain.GridCO.synchronous_early_vote_late
#check AvailableChain.GridCO.synchronous_head_handled_early
#print axioms AvailableChain.GridCO.synchronous_head_handled_early
#check AvailableChain.GridCO.synchronous_honest_head_at_gate
#print axioms AvailableChain.GridCO.synchronous_honest_head_at_gate
#check AvailableChain.GridCO.synchronous_honest_head_earlyVotes
#print axioms AvailableChain.GridCO.synchronous_honest_head_earlyVotes
#check AvailableChain.GridCO.synchronous_honest_head_resolved
#print axioms AvailableChain.GridCO.synchronous_honest_head_resolved
#check AvailableChain.GridCO.synchronous_honest_head_stored_early
#print axioms AvailableChain.GridCO.synchronous_honest_head_stored_early
#check AvailableChain.GridCO.synchronous_next_head_batch
#print axioms AvailableChain.GridCO.synchronous_next_head_batch
#check AvailableChain.GridCO.synchronous_proposal_delivered
#print axioms AvailableChain.GridCO.synchronous_proposal_delivered
#check AvailableChain.GridCO.synchronous_receipt_before
#print axioms AvailableChain.GridCO.synchronous_receipt_before
#check AvailableChain.GridCO.synchronous_release_vote_late
#print axioms AvailableChain.GridCO.synchronous_release_vote_late
#check AvailableChain.GridCO.synchronous_support_disjoint
#print axioms AvailableChain.GridCO.synchronous_support_disjoint
#check AvailableChain.GridCO.synchronous_support_subset_late
#print axioms AvailableChain.GridCO.synchronous_support_subset_late
#check AvailableChain.GridCO.synchronous_survivor_not_equivocating
#print axioms AvailableChain.GridCO.synchronous_survivor_not_equivocating
#check AvailableChain.GridCO.synchronous_voter_raw_late
#print axioms AvailableChain.GridCO.synchronous_voter_raw_late
#check AvailableChain.GridCO.tick_index_lt_delivery
#print axioms AvailableChain.GridCO.tick_index_lt_delivery
#check AvailableChain.GridCO.time_input_genuine_mem
#print axioms AvailableChain.GridCO.time_input_genuine_mem
#check AvailableChain.GridCO.time_input_genuine_origin
#print axioms AvailableChain.GridCO.time_input_genuine_origin
#check AvailableChain.GridCO.time_input_now_ge_public
#print axioms AvailableChain.GridCO.time_input_now_ge_public
#check AvailableChain.GridCO.time_input_now_lt
#print axioms AvailableChain.GridCO.time_input_now_lt
#check AvailableChain.GridCO.time_input_rootInjectiveBelow
#print axioms AvailableChain.GridCO.time_input_rootInjectiveBelow
#check AvailableChain.GridCO.time_input_row_genuine_admitted_origin
#print axioms AvailableChain.GridCO.time_input_row_genuine_admitted_origin
#check AvailableChain.GridCO.time_input_row_genuine_origin
#print axioms AvailableChain.GridCO.time_input_row_genuine_origin
#check AvailableChain.GridCO.time_input_savedGenuine
#print axioms AvailableChain.GridCO.time_input_savedGenuine
#check AvailableChain.GridCO.time_input_stamps_lt
#print axioms AvailableChain.GridCO.time_input_stamps_lt
#check AvailableChain.GridCO.time_input_target_genuine_origin
#print axioms AvailableChain.GridCO.time_input_target_genuine_origin
#check AvailableChain.GridCO.time_read_label_le
#print axioms AvailableChain.GridCO.time_read_label_le
#check AvailableChain.GridCO.time_read_now_lt
#print axioms AvailableChain.GridCO.time_read_now_lt
#check AvailableChain.GridCO.transferReceipts_from_engine
#print axioms AvailableChain.GridCO.transferReceipts_from_engine
#check AvailableChain.GridCO.transfer_from_engine
#print axioms AvailableChain.GridCO.transfer_from_engine
#check AvailableChain.GridCO.transfer_of_stronger_rows_from_engine
#print axioms AvailableChain.GridCO.transfer_of_stronger_rows_from_engine
#check AvailableChain.GridCO.voterCount_congr
#print axioms AvailableChain.GridCO.voterCount_congr
#check AvailableChain.GridCO.voterCount_eq_of_mem_or_equivocates
#print axioms AvailableChain.GridCO.voterCount_eq_of_mem_or_equivocates
#check AvailableChain.GridCO.votesAt_subset
#print axioms AvailableChain.GridCO.votesAt_subset
#check AvailableChain.GridCO.writeKeys_deadlines_aligned
#print axioms AvailableChain.GridCO.writeKeys_deadlines_aligned
#check AvailableChain.GridCO.writeKeys_def
#print axioms AvailableChain.GridCO.writeKeys_def
#check AvailableChain.GridCO.writeKeys_mem_of_key
#print axioms AvailableChain.GridCO.writeKeys_mem_of_key
#check AvailableChain.GridCO.writeKeys_now
#print axioms AvailableChain.GridCO.writeKeys_now
#check AvailableChain.GridCO.writeKeys_prefix_deadline_order
#print axioms AvailableChain.GridCO.writeKeys_prefix_deadline_order
#check AvailableChain.GridCO.writeKeys_row_origin
#print axioms AvailableChain.GridCO.writeKeys_row_origin
#check AvailableChain.GridCO.writeKeys_stable
#print axioms AvailableChain.GridCO.writeKeys_stable
#check AvailableChain.GridCO.writeObligation_row_origin
#print axioms AvailableChain.GridCO.writeObligation_row_origin
#check AvailableChain.GridCO.write_protectsUntil
#print axioms AvailableChain.GridCO.write_protectsUntil
#check AvailableChain.GridCO.write_unique_keys
#print axioms AvailableChain.GridCO.write_unique_keys
#check AvailableChain.FGSA.Run.Tests.WeakContinuationWitness.w1_strongRecovery
#print axioms AvailableChain.FGSA.Run.Tests.WeakContinuationWitness.w1_strongRecovery
#check AvailableChain.FGSA.Run.Tests.WeakContinuationWitness.w1_cleanContinuation
#print axioms AvailableChain.FGSA.Run.Tests.WeakContinuationWitness.w1_cleanContinuation
open AvailableChain AvailableChain.FGSA AvailableChain.FGSA.Run
example : ∀ p, FGSAClaims p := fgsaClaims
